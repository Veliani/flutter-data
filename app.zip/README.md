# Pencarian Data OTR (Flutter Template - Clean)

Project bersih siap build. Jika folder `android/` belum ada di ZIP ini,
gunakan workflow auto-create di GitHub Actions (atau jalankan `flutter create .`).

## Jalankan lokal
```
flutter pub get
flutter create .   # jika folder platform belum ada
flutter run
```
