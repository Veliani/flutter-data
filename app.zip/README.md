# Pencarian Data OTR (Flutter Template)

Template Flutter sederhana untuk mencari data OTR dari SQLite (`assets/harga_pasar_motor.db`). 
DB akan disalin ke direktori aplikasi saat pertama kali dijalankan.

## Fitur
- Pencarian cepat (brand/model/vehicle/object desc/region) dengan kata kunci
- Filter Brand, Region, Tahun (min/max), kisaran harga
- Tampilan daftar + detail baris
- Database preloaded dari assets

## Menjalankan
1. Pastikan Flutter SDK terpasang.
2. Buka folder ini di terminal lalu jalankan:
   ```bash
   flutter pub get
   # (opsional jika folder platform belum ada)
   flutter create .
   flutter run
   ```
3. Aplikasi akan menyalin `assets/harga_pasar_motor.db` ke folder data aplikasi dan membukanya.

## Catatan Skema
Aplikasi akan membaca skema tabel dari DB. Template ini mengasumsikan tabel utama bernama `Sheet1` 
dengan kolom umum seperti:
- BRAND, VEHICLE, MODEL, REGION, TAHUN, HARGA_PASAR, OBJECT_DESCRIPTION, dll.

Jika nama tabel/kolom berbeda, Anda dapat menyesuaikan konstanta di `lib/db_service.dart` 
dan pemetaan di `lib/main.dart` (bagian `_visibleFields`).

## Struktur
- `lib/db_service.dart`: utilitas membuka/copy DB dari assets (read-only).
- `lib/main.dart`: UI Flutter untuk pencarian dan filter.
- `assets/harga_pasar_motor.db`: database SQLite preloaded.

## Lisensi
MIT
