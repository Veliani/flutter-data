# Pencarian Data OTR v2

- Filter dirapikan + tambahan: Cabang (NAMA_CABANG), Region, Tahun, Harga
- Tampilan List & Tabel (toggle)
- Format harga otomatis **Rp** (locale `id_ID`)
- Kolom tambahan di item: `NAMA_CABANG`, `KODE_CABANG`, `REVISION`, `OBJECT_TYPE`, `GROUP_TYPE_UNIT`

Build split-per-ABI:
```
flutter build apk --release --split-per-abi
```
