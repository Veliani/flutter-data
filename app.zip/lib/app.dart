
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'pages/home_page.dart';
import 'pages/settings_page.dart';
import 'pages/about_page.dart';

class OtrApp extends StatefulWidget {
  const OtrApp({super.key});

  @override
  State<OtrApp> createState() => _OtrAppState();
}

class _OtrAppState extends State<OtrApp> {
  ThemeMode _mode = ThemeMode.system;
  bool _dark = false;
  double _textScale = 1.0;
  bool _compact = false;
  bool _ultraCompact = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    _dark = p.getBool('dark') ?? false;
    _compact = p.getBool('compact') ?? false;
    _ultraCompact = p.getBool('ultraCompact') ?? false;
    _textScale = p.getDouble('textScale') ?? 1.0;
    _mode = _dark ? ThemeMode.dark : ThemeMode.light;
    if (mounted) setState(() {});
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setBool('dark', _dark);
    await p.setBool('compact', _compact);
    await p.setBool('ultraCompact', _ultraCompact);
    await p.setDouble('textScale', _textScale);
  }

  void openSettings(BuildContext context) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => SettingsPage(
        dark: _dark,
        onDarkChanged: (v) { setState(() { _dark = v; _mode = v ? ThemeMode.dark : ThemeMode.light; }); _save(); },
        textScale: _textScale,
        onTextScaleChanged: (v) { setState(() => _textScale = v); _save(); },
        compact: _compact,
        onCompactChanged: (v) { setState(() => _compact = v); _save(); },
        ultraCompact: _ultraCompact,
        onUltraCompactChanged: (v) { setState(() => _ultraCompact = v); _save(); },
        appVersion: 'v7.3',
        onOpenAbout: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AboutPage())),
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final theme = ThemeData(
      colorSchemeSeed: Colors.indigo,
      brightness: _dark ? Brightness.dark : Brightness.light,
      useMaterial3: true,
    );

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: theme,
      darkTheme: ThemeData(
        colorSchemeSeed: Colors.indigo,
        brightness: Brightness.dark,
        useMaterial3: true,
      ),
      themeMode: _mode,
      builder: (context, child) => MediaQuery(
        data: MediaQuery.of(context).copyWith(textScaleFactor: _textScale),
        child: child!,
      ),
      home: HomePage(
        onOpenSettings: openSettings,
        compact: _compact,
        ultraCompact: _ultraCompact,
      ),
    );
  }
}
