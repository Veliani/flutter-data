import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'pages/home_page.dart';

class OtrApp extends StatefulWidget {
  const OtrApp({super.key, required this.initialDark, required this.initialTextScale, required this.initialCompact});
  final bool initialDark;
  final double initialTextScale;
  final bool initialCompact;

  @override
  State<OtrApp> createState() => _OtrAppState();
}

class _OtrAppState extends State<OtrApp> {
  late bool _dark = widget.initialDark;
  late double _textScale = widget.initialTextScale;
  late bool _compact = widget.initialCompact;

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('dark', _dark);
    await prefs.setDouble('textScale', _textScale);
    await prefs.setBool('compact', _compact);
  }

  void openSettings(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      showDragHandle: true,
      builder: (_) => StatefulBuilder(
        builder: (context, set) => Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.settings),
                    const SizedBox(width: 8),
                    const Text('Pengaturan', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                    const Spacer(),
                    IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close)),
                  ],
                ),
                const SizedBox(height: 8),
                SwitchListTile(
                  title: const Text('Dark mode'),
                  value: _dark,
                  onChanged: (v) => set(() { setState(() => _dark = v); _save(); }),
                  secondary: const Icon(Icons.dark_mode),
                  contentPadding: EdgeInsets.zero,
                ),
                const SizedBox(height: 8),
                const Text('Ukuran teks', style: TextStyle(fontWeight: FontWeight.w600)),
                Row(
                  children: [
                    const Text('Kecil'),
                    Expanded(
                      child: Slider(
                        min: 0.9, max: 1.3, divisions: 8,
                        value: _textScale,
                        onChanged: (v) => set(() { setState(() => _textScale = v); _save(); }),
                      ),
                    ),
                    const Text('Besar'),
                  ],
                ),
                const Divider(),
                SwitchListTile(
                  title: const Text('Compact mode (daftar ringkas)'),
                  value: _compact,
                  onChanged: (v) => set(() { setState(() => _compact = v); _save(); }),
                  secondary: const Icon(Icons.view_agenda_outlined),
                  contentPadding: EdgeInsets.zero,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final light = ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
      useMaterial3: true,
      inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
      dataTableTheme: const DataTableThemeData(columnSpacing: 16.0, headingRowHeight: 44),
    );
    final dark = ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue, brightness: Brightness.dark),
      useMaterial3: true,
      inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
      dataTableTheme: const DataTableThemeData(columnSpacing: 16.0, headingRowHeight: 44),
    );
    return MaterialApp(
      title: 'Pencarian Data OTR',
      debugShowCheckedModeBanner: false,
      theme: light,
      darkTheme: dark,
      themeMode: _dark ? ThemeMode.dark : ThemeMode.light,
      builder: (context, child) => MediaQuery(
        data: MediaQuery.of(context).copyWith(textScaleFactor: _textScale),
        child: child!,
      ),
      home: HomePage(
        onOpenSettings: openSettings,
        compact: _compact,
      ),
    );
  }
}
