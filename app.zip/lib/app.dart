import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'pages/home_page.dart';
import 'pages/settings_page.dart';

class OtrApp extends StatefulWidget {
  const OtrApp({super.key, required this.initialDark, required this.initialTextScale, required this.initialCompact});
  final bool initialDark;
  final double initialTextScale;
  final bool initialCompact;

  @override
  State<OtrApp> createState() => _OtrAppState();
}

class _OtrAppState extends State<OtrApp> {
  late bool _dark = widget.initialDark;
  late double _textScale = widget.initialTextScale;
  late bool _compact = widget.initialCompact;

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('dark', _dark);
    await prefs.setDouble('textScale', _textScale);
    await prefs.setBool('compact', _compact);
  }

  void openSettings(BuildContext context) {
  Navigator.of(context).push(MaterialPageRoute(
    builder: (_) => SettingsPage(
      dark: _dark,
      onDarkChanged: (v) { setState(() => _dark = v); _save(); },
      textScale: _textScale,
      onTextScaleChanged: (v) { setState(() => _textScale = v); _save(); },
      compact: _compact,
      onCompactChanged: (v) { setState(() => _compact = v); _save(); },
      appVersion: 'v7.1',
    ),
  ));
}

  @override
  Widget build(BuildContext context) {
    final light = ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
      useMaterial3: true,
      inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
      dataTableTheme: const DataTableThemeData(columnSpacing: 16.0, headingRowHeight: 44),
    );
    final dark = ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue, brightness: Brightness.dark),
      useMaterial3: true,
      inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
      dataTableTheme: const DataTableThemeData(columnSpacing: 16.0, headingRowHeight: 44),
    );
    return MaterialApp(
      title: 'Pencarian Data OTR',
      debugShowCheckedModeBanner: false,
      theme: light,
      darkTheme: dark,
      themeMode: _dark ? ThemeMode.dark : ThemeMode.light,
      builder: (context, child) => MediaQuery(
        data: MediaQuery.of(context).copyWith(textScaleFactor: _textScale),
        child: child!,
      ),
      home: HomePage(
        onOpenSettings: openSettings,
        compact: _compact,
      ),
    );
  }
}
