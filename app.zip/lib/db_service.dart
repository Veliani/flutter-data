import 'dart:io';
import 'package:flutter/services.dart' show rootBundle, ByteData;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class DbService {
  static const String assetDbPath = 'assets/harga_pasar_motor.db';
  static const String databaseFileName = 'harga_pasar_motor.db';

  static Future<Database> openPreloadedDb() async {
    final Directory docs = await getApplicationDocumentsDirectory();
    final String dbPath = p.join(docs.path, databaseFileName);

    // Copy once from assets if not exists
    final File dbFile = File(dbPath);
    if (!await dbFile.exists()) {
      final ByteData data = await rootBundle.load(assetDbPath);
      final List<int> bytes =
          data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
      await dbFile.writeAsBytes(bytes, flush: true);
    }

    return openDatabase(dbPath, readOnly: true);
  }
}
