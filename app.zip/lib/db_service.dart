
import 'dart:async';
import 'dart:io';
import 'package:flutter/services.dart' show rootBundle, ByteData;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:http/http.dart' as http;
import 'config.dart';

class DbService {
  static const String assetDbPath = 'assets/harga_pasar_motor.db';
  static const String databaseFileName = 'harga_pasar_motor.db';

  static Future<String> _localDbPath() async {
    final dir = await getApplicationDocumentsDirectory();
    return p.join(dir.path, databaseFileName);
  }

  static Future<Database> openPreloadedDb() async {
    final dbPath = await _localDbPath();
    final file = File(dbPath);
    if (!await file.exists()) {
      final ByteData data = await rootBundle.load(assetDbPath);
      final bytes = data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
      await file.writeAsBytes(bytes, flush: true);
    }
    return openDatabase(dbPath, readOnly: true);
  }

  static Future<void> updateDbFromGitHub() async {
    final token = AppConfig.githubToken;
    if (token == 'PASTE_YOUR_TOKEN_HERE' || token.trim().isEmpty) {
      throw Exception('GitHub token belum diisi di lib/config.dart');
    }

    final headers = {
      'Accept': 'application/vnd.github.raw',
      'Authorization': 'token $token',
      'User-Agent': 'otr-updater',
    };
    final urls = [
      'https://api.github.com/repos/${AppConfig.githubRepoUser}/${AppConfig.githubRepoName}/contents/${AppConfig.githubFilePath}?ref=${AppConfig.githubBranch}',
      'https://raw.githubusercontent.com/${AppConfig.githubRepoUser}/${AppConfig.githubRepoName}/${AppConfig.githubBranch}/${AppConfig.githubFilePath}',
    ];
    http.Response? ok;
    for (var i = 0; i < urls.length; i++) {
      try {
        final res = await http.get(Uri.parse(urls[i]), headers: i == 0 ? headers : {'User-Agent': 'otr-updater'}).timeout(const Duration(seconds: 12));
        if (res.statusCode == 200 && res.bodyBytes.isNotEmpty) { ok = res; break; }
      } catch (_) {}
    }
    if (ok == null) throw Exception('Tidak bisa mengunduh dari GitHub (cek Internet/Private DNS/Wi‑Fi).');

    final tmpPath = (await _localDbPath()).replaceFirst(databaseFileName, 'tmp_$databaseFileName');
    final tmp = File(tmpPath);
    await tmp.writeAsBytes(ok.bodyBytes, flush: true);
    if (await tmp.length() == 0) { await tmp.delete().catchError((_) {}); throw Exception('File DB dari GitHub kosong'); }
    final dbPath = await _localDbPath();
    if (await File(dbPath).exists()) await File(dbPath).delete();
    await tmp.rename(dbPath);
  }
}
