import 'dart:async';
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'db_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  final onboarded = prefs.getBool('onboarded') ?? false;
  runApp(OtrApp(
    initialDark: prefs.getBool('dark') ?? false,
    initialTextScale: prefs.getDouble('textScale') ?? 1.0,
    initialCompact: prefs.getBool('compact') ?? false,
    showOnboarding: !onboarded,
  ));
}

class OtrApp extends StatefulWidget {
  const OtrApp({
    super.key,
    required this.initialDark,
    required this.initialTextScale,
    required this.initialCompact,
    required this.showOnboarding,
  });
  final bool initialDark;
  final double initialTextScale;
  final bool initialCompact;
  final bool showOnboarding;

  @override
  State<OtrApp> createState() => _OtrAppState();
}

class _OtrAppState extends State<OtrApp> {
  late bool _dark = widget.initialDark;
  late double _textScale = widget.initialTextScale;
  late bool _compact = widget.initialCompact;

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setBool('dark', _dark);
    await p.setDouble('textScale', _textScale);
    await p.setBool('compact', _compact);
  }

  @override
  Widget build(BuildContext context) {
    final lightScheme = ColorScheme.fromSeed(seedColor: Colors.indigo, brightness: Brightness.light);
    final darkScheme  = ColorScheme.fromSeed(seedColor: Colors.indigo, brightness: Brightness.dark);
    final density = _compact ? VisualDensity.compact : VisualDensity.standard;

    final theme = ThemeData(
      useMaterial3: true,
      colorScheme: lightScheme,
      inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
      listTileTheme: ListTileThemeData(visualDensity: density),
    );
    final darkTheme = ThemeData(
      useMaterial3: true,
      colorScheme: darkScheme,
      inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
      listTileTheme: ListTileThemeData(visualDensity: density),
    );

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Pencarian Data OTR',
      theme: theme,
      darkTheme: darkTheme,
      themeMode: _dark ? ThemeMode.dark : ThemeMode.light,
      builder: (context, child) => MediaQuery(
        data: MediaQuery.of(context).copyWith(textScaleFactor: _textScale),
        child: child!,
      ),
      home: widget.showOnboarding ? Onboarding(onFinish: () async {
        final p = await SharedPreferences.getInstance();
        await p.setBool('onboarded', true);
        setState(() {});
      }) : HomePage(
        onOpenSettings: _openSettings,
      ),
    );
  }

  void _openSettings(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      showDragHandle: true,
      builder: (_) => StatefulBuilder(
        builder: (context, set) => Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          child: ListView(
            shrinkWrap: true,
            children: [
              const Text('Pengaturan', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              ListTile(
                leading: const Icon(Icons.color_lens_outlined),
                title: const Text('Tampilan'),
                subtitle: const Text('Tema gelap/terang, compact, ukuran teks'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(builder: (_) => _AppearancePage(
                    dark: _dark,
                    compact: _compact,
                    textScale: _textScale,
                    onChanged: (d, c, t) {
                      set(() { setState(() { _dark=d; _compact=c; _textScale=t; }); _save(); });
                    },
                  )));
                },
              ),
              ListTile(
                leading: const Icon(Icons.sort),
                title: const Text('Urutkan data'),
                subtitle: const Text('Model/Tahun/Harga/Revision, ASC/DESC'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () async {
                  final result = await Navigator.of(context).push<Map<String, dynamic>>(
                    MaterialPageRoute(builder: (_) => const _SortPage()));
                  if (result != null && context.mounted) {
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Aturan sortir disimpan')));
                  }
                },
              ),
              ListTile(
                leading: const Icon(Icons.info_outline),
                title: const Text('Info database'),
                onTap: () async {
                  final info = await DbService.dbInfo();
                  showDialog(context: context, builder: (_) => AlertDialog(
                    title: const Text('Info database'),
                    content: Text('Path: ${info['path']}\nSize: ${info['size']} bytes\nModified: ${info['modified']}'),
                    actions: [TextButton(onPressed: ()=>Navigator.pop(context), child: const Text('Tutup'))],
                  ));
                },
              ),
              ListTile(
                leading: const Icon(Icons.cloud_download_outlined),
                title: const Text('Update database dari GitHub'),
                onTap: () async {
                  Navigator.pop(context);
                  await HomePage.updateDbFromGitHub(context);
                },
              ),
              ListTile(
                leading: const Icon(Icons.article_outlined),
                title: const Text('Changelog'),
                onTap: () {
                  showModalBottomSheet(context: context, builder: (_) => const _ChangelogSheet(), useSafeArea: true);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AppearancePage extends StatefulWidget {
  const _AppearancePage({required this.dark, required this.compact, required this.textScale, required this.onChanged});
  final bool dark;
  final bool compact;
  final double textScale;
  final void Function(bool,bool,double) onChanged;

  @override
  State<_AppearancePage> createState() => _AppearancePageState();
}

class _AppearancePageState extends State<_AppearancePage> {
  late bool _dark = widget.dark;
  late bool _compact = widget.compact;
  late double _textScale = widget.textScale;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tampilan')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            SwitchListTile(
              title: const Text('Dark mode'),
              value: _dark,
              onChanged: (v){ setState(()=>_dark=v); widget.onChanged(_dark,_compact,_textScale); },
              secondary: const Icon(Icons.dark_mode),
            ),
            SwitchListTile(
              title: const Text('Tampilan compact'),
              value: _compact,
              onChanged: (v){ setState(()=>_compact=v); widget.onChanged(_dark,_compact,_textScale); },
              secondary: const Icon(Icons.view_agenda_outlined),
            ),
            Row(children:[
              const Text('Ukuran teks'), const SizedBox(width: 8),
              Expanded(child: Slider(min:0.9,max:1.3,divisions:8,value:_textScale,
                onChanged:(v){ setState(()=>_textScale=v); widget.onChanged(_dark,_compact,_textScale); })),
            ]),
          ],
        ),
      ),
    );
  }
}

class _SortPage extends StatefulWidget {
  const _SortPage();
  @override
  State<_SortPage> createState() => _SortPageState();
}

class _SortPageState extends State<_SortPage> {
  final keys = const ['MODEL','TAHUN','HARGA_PASAR','REVISION'];
  String key = 'MODEL';
  bool asc = true;

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p){
      setState((){
        key = p.getString('sortKey') ?? 'MODEL';
        asc = p.getBool('sortAsc') ?? true;
      });
    });
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('sortKey', key);
    await p.setBool('sortAsc', asc);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Urutkan data')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            DropdownButtonFormField<String>(
              value: key,
              items: keys.map((e)=>DropdownMenuItem(value:e, child: Text(e))).toList(),
              onChanged: (v){ if (v!=null) setState(()=>key=v); },
              decoration: const InputDecoration(labelText: 'Kolom'),
            ),
            const SizedBox(height: 12),
            SwitchListTile(
              title: const Text('Ascending'),
              value: asc,
              onChanged: (v)=>setState(()=>asc=v),
            ),
            const SizedBox(height: 16),
            FilledButton(onPressed: () async { await _save(); if (context.mounted) Navigator.pop(context, {'ok':true}); }, child: const Text('Simpan')),
          ],
        ),
      ),
    );
  }
}

class _ChangelogSheet extends StatelessWidget {
  const _ChangelogSheet();

  @override
  Widget build(BuildContext context) {
    final items = [
      ('v8.7.1', ['Perbaikan tipe Dropdown (null-safety)']),
      ('v8.7', ['Merge fitur: onboarding, filter toggle, suggestions, sorting submenu, detail view', 'Perbaikan infinite scroll & dark mode','DB RW + update dari GitHub']),
      ('v8.6.1', ['Perbaikan read-only & dark mode']),
      ('v8.6', ['Paging & dark theme awal']),
    ];
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            const Text('Changelog', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            for (final item in items) ...[
              Text(item.$1, style: const TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 6),
              ...item.$2.map((e)=>Padding(padding: const EdgeInsets.only(left:8,bottom:4), child: Text('• $e'))),
              const SizedBox(height: 12),
            ]
          ],
        ),
      ),
    );
  }
}

class Onboarding extends StatefulWidget {
  const Onboarding({super.key, required this.onFinish});
  final Future<void> Function() onFinish;

  @override
  State<Onboarding> createState() => _OnboardingState();
}

class _OnboardingState extends State<Onboarding> {
  final ctrl = PageController();
  int page = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Expanded(child: PageView(
              controller: ctrl,
              onPageChanged: (i)=>setState(()=>page=i),
              children: const [
                _OnboardSlide(icon: Icons.search, title: 'Cari Data OTR', text: 'Ketik kata kunci untuk mencari berdasarkan brand, model, vehicle, deskripsi, atau region.'),
                _OnboardSlide(icon: Icons.tune, title: 'Filter & Urutkan', text: 'Gunakan filter dan atur urutan data di pengaturan.'),
                _OnboardSlide(icon: Icons.dark_mode, title: 'Tema & Compact Mode', text: 'Sesuaikan tampilan: dark/light, ukuran teks, dan mode compact.'),
              ],
            )),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextButton(onPressed: () async { await widget.onFinish(); if (context.mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_)=>const HomePage(onOpenSettings: _noop))); }, child: const Text('Lewati')),
                Row(children: List.generate(3, (i)=>Container(width:8,height:8,margin:const EdgeInsets.all(4),decoration: BoxDecoration(shape: BoxShape.circle,color: i==page? Theme.of(context).colorScheme.primary: Colors.grey)) )),
                Padding(
                  padding: const EdgeInsets.only(right:8),
                  child: FilledButton(onPressed: () async {
                    if (page<2) { ctrl.nextPage(duration: const Duration(milliseconds: 250), curve: Curves.easeOut); }
                    else { await widget.onFinish(); if (context.mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_)=>const HomePage(onOpenSettings: _noop))); }
                  }, child: Text(page<2?'Lanjut':'Mulai')),
                ),
              ],
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }
}

void _noop(BuildContext _) {}

class _OnboardSlide extends StatelessWidget {
  const _OnboardSlide({required this.icon, required this.title, required this.text});
  final IconData icon;
  final String title;
  final String text;
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 72),
            const SizedBox(height: 16),
            Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Text(text, textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.onOpenSettings});
  final void Function(BuildContext) onOpenSettings;

  static Future<void> updateDbFromGitHub(BuildContext context) async {
    try {
      final conn = await Connectivity().checkConnectivity();
      if (conn == ConnectivityResult.none) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Tidak ada koneksi internet.')));
        return;
      }
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Mengunduh database...')));
      await DbService.updateDbFromGitHub();
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Database diperbarui. Tutup & buka ulang aplikasi untuk memuat ulang.')));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal update: $e')));
    }
  }

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Database? _db;
  bool _loading = true;

  final _searchCtrl = TextEditingController();
  Timer? _debounce;
  String _keyword = '';
  List<String> _suggestions = [];

  bool _showFilters = false;
  String? _brand;
  String? _region;
  int? _yearMin;
  int? _yearMax;
  int? _priceMin;
  int? _priceMax;
  int _priceAbsMin = 0;
  int _priceAbsMax = 100000000;

  String _sortKey = 'MODEL';
  bool _sortAsc = true;

  final _scroll = ScrollController();
  final String _table = 'Sheet1';
  final List<String> _cols = const [
    'BRAND','VEHICLE','MODEL','REGION','TAHUN','HARGA_PASAR',
    'OBJECT_DESCRIPTION','NAMA_CABANG','KODE_CABANG','REVISION','OBJECT_TYPE','GROUP_TYPE_UNIT'
  ];
  List<Map<String,Object?>> _rows = [];
  int _limit = 50, _offset = 0;
  bool _hasMore = true, _isLoadingMore = false;

  final _rupiah = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp.', decimalDigits: 0);

  @override
  void initState() {
    super.initState();
    Intl.defaultLocale = 'id_ID';
    _initDb();
    _scroll.addListener(() {
      if (_scroll.position.pixels >= _scroll.position.maxScrollExtent - 80) {
        _loadMore();
      }
    });
    _loadSortPrefs();
  }

  Future<void> _loadSortPrefs() async {
    final p = await SharedPreferences.getInstance();
    setState(() {
      _sortKey = p.getString('sortKey') ?? 'MODEL';
      _sortAsc = p.getBool('sortAsc') ?? true;
    });
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _scroll.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _initDb() async {
    _db = await DbService.openPreloadedDb();
    await _loadPriceRange();
    setState(()=>_loading=false);
    await _refresh();
  }

  Future<void> _loadPriceRange() async {
    if (_db == null) return;
    final r = await _db!.rawQuery('SELECT MIN(HARGA_PASAR) as minH, MAX(HARGA_PASAR) as maxH FROM $_table');
    final min = (r.first['minH'] as num?)?.toInt() ?? 0;
    final max = (r.first['maxH'] as num?)?.toInt() ?? 100000000;
    _priceAbsMin = min;
    _priceAbsMax = max;
    _priceMin ??= min;
    _priceMax ??= max;
  }

  String _where(List<Object?> argsOut) {
    final parts = <String>[];
    if (_keyword.trim().isNotEmpty) {
      final like = '%${_keyword.trim()}%';
      parts.add('(BRAND LIKE ? OR VEHICLE LIKE ? OR MODEL LIKE ? OR REGION LIKE ? OR OBJECT_DESCRIPTION LIKE ?)');
      argsOut.addAll([like,like,like,like,like]);
    }
    if (_brand != null && _brand!.isNotEmpty) { parts.add('BRAND = ?'); argsOut.add(_brand); }
    if (_region != null && _region!.isNotEmpty) { parts.add('REGION = ?'); argsOut.add(_region); }
    if (_yearMin != null) { parts.add('TAHUN >= ?'); argsOut.add(_yearMin); }
    if (_yearMax != null) { parts.add('TAHUN <= ?'); argsOut.add(_yearMax); }
    if (_priceMin != null) { parts.add('HARGA_PASAR >= ?'); argsOut.add(_priceMin); }
    if (_priceMax != null) { parts.add('HARGA_PASAR <= ?'); argsOut.add(_priceMax); }
    return parts.isEmpty ? '' : 'WHERE ' + parts.join(' AND ');
  }

  String _orderBy() {
    final dir = _sortAsc ? 'ASC' : 'DESC';
    return 'ORDER BY $_sortKey $dir, MODEL ASC';
  }

  Future<void> _refresh() async {
    if (_db == null) return;
    setState((){ _loading=true; _rows=[]; _offset=0; _hasMore=true; });
    final args=<Object?>[]; final where=_where(args); final order=_orderBy();
    final sql='SELECT ${_cols.join(', ')} FROM $_table $where $order LIMIT $_limit OFFSET 0';
    final res=await _db!.rawQuery(sql, args);
    setState((){
      _rows=res; _offset=res.length; _hasMore=res.length==_limit; _loading=false;
    });
  }

  Future<void> _loadMore() async {
    if (!_hasMore || _db==null || _isLoadingMore) return;
    setState(()=>_isLoadingMore=true);
    try {
      final args=<Object?>[]; final where=_where(args); final order=_orderBy();
      final sql='SELECT ${_cols.join(', ')} FROM $_table $where $order LIMIT $_limit OFFSET $_offset';
      final res=await _db!.rawQuery(sql, args);
      setState((){
        _rows.addAll(res); _offset+=res.length; _hasMore=res.length==_limit;
      });
    } catch (e) {
      if (mounted) {
        _hasMore=false;
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Load lebih gagal: $e')));
      }
    } finally {
      if (mounted) setState(()=>_isLoadingMore=false);
    }
  }

  Future<void> _fetchSuggestions(String q) async {
    if (_db == null || q.trim().length < 2) { setState(()=>_suggestions=[]); return; }
    final like = '${q.trim()}%';
    final r1 = await _db!.rawQuery('SELECT DISTINCT MODEL AS v FROM $_table WHERE MODEL LIKE ? LIMIT 5', [like]);
    final r2 = await _db!.rawQuery('SELECT DISTINCT BRAND AS v FROM $_table WHERE BRAND LIKE ? LIMIT 3', [like]);
    final r3 = await _db!.rawQuery('SELECT DISTINCT VEHICLE AS v FROM $_table WHERE VEHICLE LIKE ? LIMIT 3', [like]);
    final set = <String>{};
    for (final r in [...r1,...r2,...r3]) {
      final v = (r['v'] ?? '').toString().trim();
      if (v.isNotEmpty) set.add(v);
    }
    setState(()=>_suggestions=set.toList());
  }

  void _onSearchChanged(String v) {
    _debounce?.cancel();
    _debounce=Timer(const Duration(milliseconds: 250), (){
      setState(()=>_keyword=v);
      _refresh();
      _fetchSuggestions(v);
    });
  }

  Future<List<String>> _distinctValues(String column) async {
    final r = await _db!.rawQuery('SELECT DISTINCT $column as v FROM $_table ORDER BY v ASC');
    return r.map((e)=> (e['v'] ?? '').toString()).where((e)=>e.trim().isNotEmpty).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pencarian Data OTR'),
        actions: [
          IconButton(icon: const Icon(Icons.info_outline), onPressed: () async {
            final info = await DbService.dbInfo();
            if (!mounted) return;
            showDialog(context: context, builder: (_) => AlertDialog(
              title: const Text('Info database'),
              content: Text('Path: ${info['path']}\nSize: ${info['size']} bytes\nModified: ${info['modified']}'),
              actions: [TextButton(onPressed: ()=>Navigator.pop(context), child: const Text('Tutup'))],
            ));
          }),
          IconButton(icon: const Icon(Icons.settings), onPressed: ()=>widget.onOpenSettings(context)),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12,10,12,6),
            child: Row(children:[
              Expanded(child: Column(
                children: [
                  TextField(
                    controller: _searchCtrl,
                    decoration: const InputDecoration(
                      labelText: 'Kata kunci (brand/model/vehicle/desc/region)',
                      prefixIcon: Icon(Icons.search),
                    ),
                    onChanged: _onSearchChanged,
                  ),
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    height: _suggestions.isEmpty ? 0 : 42,
                    alignment: Alignment.centerLeft,
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.only(top:6),
                      child: Row(children: _suggestions.map((s)=> Padding(
                        padding: const EdgeInsets.only(right:8),
                        child: ActionChip(label: Text(s), onPressed: (){ _searchCtrl.text=s; _onSearchChanged(s); }),
                      )).toList()),
                    ),
                  )
                ],
              )),
              const SizedBox(width:8),
              FilledButton.icon(onPressed: _refresh, icon: const Icon(Icons.search), label: const Text('Cari')),
              const SizedBox(width:8),
              IconButton(onPressed: () async { setState(()=>_showFilters=!_showFilters); }, icon: const Icon(Icons.tune)),
            ]),
          ),
          AnimatedCrossFade(
            firstChild: const SizedBox.shrink(),
            secondChild: FutureBuilder(
              future: Future.wait([_distinctValues('BRAND'), _distinctValues('REGION'), _distinctValues('TAHUN')]),
              builder: (context, snapshot) {
                final brands = snapshot.hasData ? (snapshot.data![0] as List<String>) : <String>[];
                final regions = snapshot.hasData ? (snapshot.data![1] as List<String>) : <String>[];
                final years = snapshot.hasData ? (snapshot.data![2] as List<String>) : <String>[];
                final yearInts = years.map((e)=>int.tryParse(e)??0).where((e)=>e>0).toList()..sort();
                return Padding(
                  padding: const EdgeInsets.fromLTRB(12,0,12,8),
                  child: Column(
                    children: [
                      Row(children: [
                        Expanded(child: DropdownButtonFormField<String?>(
                          value: _brand,
                          items: [const DropdownMenuItem<String?>(value: null, child: Text('-'))] +
                              brands.map((e)=>DropdownMenuItem<String?>(value:e, child: Text(e))).toList(),
                          onChanged: (v){ setState(()=>_brand=v); },
                          decoration: const InputDecoration(labelText: 'Brand'),
                        )),
                        const SizedBox(width: 12),
                        Expanded(child: DropdownButtonFormField<String?>(
                          value: _region,
                          items: [const DropdownMenuItem<String?>(value: null, child: Text('-'))] +
                              regions.map((e)=>DropdownMenuItem<String?>(value:e, child: Text(e))).toList(),
                          onChanged: (v){ setState(()=>_region=v); },
                          decoration: const InputDecoration(labelText: 'Region'),
                        )),
                      ]),
                      const SizedBox(height: 8),
                      Row(children: [
                        Expanded(child: DropdownButtonFormField<int?>(
                          value: _yearMin,
                          items: [const DropdownMenuItem<int?>(value: null, child: Text('-'))] +
                              yearInts.map((e)=>DropdownMenuItem<int?>(value:e, child: Text('$e'))).toList(),
                          onChanged: (v){ setState(()=>_yearMin=v); },
                          decoration: const InputDecoration(labelText: 'Tahun min'),
                        )),
                        const SizedBox(width: 12),
                        Expanded(child: DropdownButtonFormField<int?>(
                          value: _yearMax,
                          items: [const DropdownMenuItem<int?>(value: null, child: Text('-'))] +
                              yearInts.map((e)=>DropdownMenuItem<int?>(value:e, child: Text('$e'))).toList(),
                          onChanged: (v){ setState(()=>_yearMax=v); },
                          decoration: const InputDecoration(labelText: 'Tahun max'),
                        )),
                      ]),
                      const SizedBox(height: 8),
                      Row(children: [
                        Expanded(child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Harga (Rp)'),
                            SliderTheme(data: const SliderThemeData(showValueIndicator: ShowValueIndicator.always), child:
                              RangeSlider(
                                values: RangeValues((_priceMin??_priceAbsMin).toDouble(), (_priceMax??_priceAbsMax).toDouble()),
                                min: _priceAbsMin.toDouble(),
                                max: _priceAbsMax.toDouble(),
                                divisions: 50,
                                labels: RangeLabels(_rupiah.format(_priceMin??_priceAbsMin), _rupiah.format(_priceMax??_priceAbsMax)),
                                onChanged: (v){ setState(()=>{_priceMin=v.start.toInt(), _priceMax=v.end.toInt()}); },
                              ))
                          ],
                        )),
                      ]),
                      Row(children: [
                        Expanded(child: OutlinedButton.icon(onPressed: (){ setState((){ _brand=null; _region=null; _yearMin=null; _yearMax=null; _priceMin=_priceAbsMin; _priceMax=_priceAbsMax; }); _refresh(); }, icon: const Icon(Icons.refresh), label: const Text('Reset'))),
                        const SizedBox(width: 12),
                        Expanded(child: FilledButton.icon(onPressed: _refresh, icon: const Icon(Icons.filter_alt), label: const Text('Terapkan'))),
                      ]),
                      const Divider(height: 16),
                    ],
                  ),
                );
              },
            ),
            crossFadeState: _showFilters ? CrossFadeState.showSecond : CrossFadeState.showFirst,
            duration: const Duration(milliseconds: 250),
          ),
          if (_loading) const LinearProgressIndicator(minHeight: 2),
          Expanded(child: _buildList()),
        ],
      ),
    );
  }

  ImageProvider _brandIcon(String brand) {
    final b = brand.toLowerCase();
    if (b.contains('yamaha')) return const AssetImage('assets/icons/yamaha.png');
    if (b.contains('honda')) return const AssetImage('assets/icons/honda.png');
    if (b.contains('suzuki')) return const AssetImage('assets/icons/suzuki.png');
    if (b.contains('kawasaki')) return const AssetImage('assets/icons/kawasaki.png');
    if (b.contains('tvs')) return const AssetImage('assets/icons/tvs.png');
    return const AssetImage('assets/icons/default.png');
  }

  void _openDetail(Map<String,Object?> r) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      showDragHandle: true,
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(16,8,16,24),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children:[
            CircleAvatar(backgroundImage:_brandIcon((r['BRAND']??'').toString())),
            const SizedBox(width: 12),
            Expanded(child: Text('${r['MODEL']??''}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700))),
            Text(_rupiah.format((r['HARGA_PASAR']??0))), 
          ]),
          const SizedBox(height: 8),
          _kv('Brand', r['BRAND']), _kv('Vehicle', r['VEHICLE']),
          _kv('Region', r['REGION']), _kv('Tahun', r['TAHUN']),
          _kv('Deskripsi', r['OBJECT_DESCRIPTION']),
          _kv('Cabang', r['NAMA_CABANG']), _kv('Kode Cabang', r['KODE_CABANG']),
          _kv('Revision', _rupiah.format((r['REVISION']??0))),
          _kv('Object Type', r['OBJECT_TYPE']), _kv('Group Type', r['GROUP_TYPE_UNIT']),
          const SizedBox(height: 12),
        ]),
      ),
    );
  }

  Widget _kv(String k, Object? v) => v==null || v.toString().trim().isEmpty ? const SizedBox.shrink() : Padding(
    padding: const EdgeInsets.only(bottom:6), child: Row(children:[
      SizedBox(width: 110, child: Text(k, style: const TextStyle(color: Colors.grey))),
      const SizedBox(width: 8),
      Expanded(child: Text(v.toString())),
    ]));

  Widget _buildList(){
    final itemCount=_rows.length+(_hasMore?1:0);
    return RefreshIndicator(
      onRefresh: _refresh,
      child: ListView.separated(
        controller: _scroll,
        itemCount: itemCount,
        separatorBuilder: (_, __)=>const Divider(height:1),
        itemBuilder: (context,i){
          if (i>=_rows.length){
            if (_hasMore){
              _loadMore();
              return const Padding(
                padding: EdgeInsets.symmetric(vertical:16),
                child: Center(child: CircularProgressIndicator(strokeWidth:2)),
              );
            }
            return const SizedBox.shrink();
          }
          final r=_rows[i];
          String h(dynamic v)=>_rupiah.format((num.tryParse(v.toString())??0).round());
          final desc=(r['OBJECT_DESCRIPTION']??'').toString().trim();
          final showDesc = desc.isNotEmpty && !RegExp(r'^\d{4}(\s*(-|/)\s*\d{4})?$').hasMatch(desc);
          return ListTile(
            onTap: ()=>_openDetail(r),
            leading: CircleAvatar(backgroundImage:_brandIcon((r['BRAND']??'').toString())),
            title: Text('${r['MODEL']??''}', style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text('${r['VEHICLE']??''} • ${r['REGION']??''} • ${r['TAHUN']??''}'+(showDesc? '\n$desc' : ''), maxLines: 2),
            trailing: Column(crossAxisAlignment: CrossAxisAlignment.end, mainAxisAlignment: MainAxisAlignment.center, children: [
              Text(h(r['HARGA_PASAR']), style: const TextStyle(fontWeight: FontWeight.bold)),
              Text('Rev: '+h(r['REVISION']??0), style: const TextStyle(fontSize: 12)),
            ]),
          );
        },
      ),
    );
  }
}
