import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'db_service.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const OtrApp());
}

class OtrApp extends StatelessWidget {
  const OtrApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pencarian Data OTR',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Database? _db;
  bool _loading = true;
  String _keyword = '';
  String? _brand;
  String? _region;
  String? _tahunMin;
  String? _tahunMax;
  int? _hargaMin;
  int? _hargaMax;

  final String _table = 'Sheet1';
  final List<String> _visibleFields = const [
    'BRAND',
    'VEHICLE',
    'MODEL',
    'REGION',
    'TAHUN',
    'HARGA_PASAR',
    'OBJECT_DESCRIPTION'
  ];

  List<String> _brands = [];
  List<String> _regions = [];
  List<String> _tahuns = [];

  List<Map<String, Object?>> _rows = [];
  int _limit = 50;
  int _offset = 0;
  bool _hasMore = true;

  @override
  void initState() {
    super.initState();
    _initDb();
  }

  Future<void> _initDb() async {
    final db = await DbService.openPreloadedDb();
    final brands = await db.rawQuery('SELECT DISTINCT BRAND FROM $_table WHERE BRAND IS NOT NULL AND TRIM(BRAND) != "" ORDER BY BRAND');
    final regions = await db.rawQuery('SELECT DISTINCT REGION FROM $_table WHERE REGION IS NOT NULL AND TRIM(REGION) != "" ORDER BY REGION');
    final tahuns = await db.rawQuery('SELECT DISTINCT TAHUN FROM $_table WHERE TAHUN IS NOT NULL AND TRIM(TAHUN) != "" ORDER BY TAHUN');

    setState(() {
      _db = db;
      _brands = brands.map((e) => (e['BRAND'] ?? '').toString()).toList();
      _regions = regions.map((e) => (e['REGION'] ?? '').toString()).toList();
      _tahuns = tahuns.map((e) => (e['TAHUN'] ?? '').toString()).toList();
      _loading = false;
    });

    await _refresh();
  }

  Future<void> _refresh() async {
    if (_db == null) return;
    setState(() {
      _loading = true;
      _rows = [];
      _offset = 0;
      _hasMore = true;
    });
    await _loadMore();
    setState(() {
      _loading = false;
    });
  }

  String _buildWhereClause(List<Object?> argsOut) {
    final List<String> parts = [];
    if (_keyword.trim().isNotEmpty) {
      final like = '%${_keyword.trim()}%';
      parts.add('('
          'BRAND LIKE ? OR VEHICLE LIKE ? OR MODEL LIKE ? OR OBJECT_DESCRIPTION LIKE ? OR REGION LIKE ?'
          ')');
      argsOut.addAll([like, like, like, like, like]);
    }
    if (_brand != null && _brand!.isNotEmpty) {
      parts.add('BRAND = ?');
      argsOut.add(_brand);
    }
    if (_region != null && _region!.isNotEmpty) {
      parts.add('REGION = ?');
      argsOut.add(_region);
    }
    if (_tahunMin != null && _tahunMin!.isNotEmpty) {
      parts.add('(CAST(COALESCE(MIN_YEAR, TAHUN) AS INTEGER) >= ?)');
      argsOut.add(int.tryParse(_tahunMin!) ?? 0);
    }
    if (_tahunMax != null && _tahunMax!.isNotEmpty) {
      parts.add('(CAST(COALESCE(MAX_YEAR, TAHUN) AS INTEGER) <= ?)');
      argsOut.add(int.tryParse(_tahunMax!) ?? 9999);
    }
    if (_hargaMin != null) {
      parts.add('HARGA_PASAR >= ?');
      argsOut.add(_hargaMin);
    }
    if (_hargaMax != null) {
      parts.add('HARGA_PASAR <= ?');
      argsOut.add(_hargaMax);
    }
    return parts.isEmpty ? '' : 'WHERE ' + parts.join(' AND ');
  }

  Future<void> _loadMore() async {
    if (!_hasMore || _db == null) return;
    final List<Object?> args = [];
    final whereClause = _buildWhereClause(args);
    final sql =
        'SELECT ${_visibleFields.join(', ')} FROM $_table $whereClause ORDER BY BRAND, MODEL, TAHUN LIMIT $_limit OFFSET $_offset';
    final result = await _db!.rawQuery(sql, args);
    setState(() {
      _rows.addAll(result);
      _offset += result.length;
      _hasMore = result.length == _limit;
    });
  }

  void _resetFilters() {
    setState(() {
      _keyword = '';
      _brand = null;
      _region = null;
      _tahunMin = null;
      _tahunMax = null;
      _hargaMin = null;
      _hargaMax = null;
    });
    _refresh();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pencarian Data OTR'),
        actions: [
          IconButton(
            tooltip: 'Reset filter',
            onPressed: _resetFilters,
            icon: const Icon(Icons.refresh),
          )
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                _buildFilters(context),
                const Divider(height: 1),
                Expanded(child: _buildResults()),
              ],
            ),
    );
  }

  Widget _buildFilters(BuildContext context) {
    final inputBorder = OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
    );

    return Padding(
      padding: const EdgeInsets.all(12.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: TextField(
                  decoration: InputDecoration(
                    labelText: 'Kata kunci (brand/model/vehicle/desc/region)',
                    border: inputBorder,
                    prefixIcon: const Icon(Icons.search),
                  ),
                  onSubmitted: (v) {
                    setState(() => _keyword = v);
                    _refresh();
                  },
                ),
              ),
              const SizedBox(width: 8),
              FilledButton.icon(
                onPressed: _refresh,
                icon: const Icon(Icons.tune),
                label: const Text('Cari'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _buildDropdown('Brand', _brands, _brand, (v) {
                setState(() => _brand = v);
              }),
              _buildDropdown('Region', _regions, _region, (v) {
                setState(() => _region = v);
              }),
              _buildDropdown('Tahun min', _tahuns, _tahunMin, (v) {
                setState(() => _tahunMin = v);
              }),
              _buildDropdown('Tahun max', _tahuns, _tahunMax, (v) {
                setState(() => _tahunMax = v);
              }),
              _buildNumberField('Harga min', (v) {
                _hargaMin = v.isEmpty ? null : int.tryParse(v);
              }),
              _buildNumberField('Harga max', (v) {
                _hargaMax = v.isEmpty ? null : int.tryParse(v);
              }),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildDropdown(
    String label,
    List<String> options,
    String? value,
    void Function(String?) onChanged,
  ) {
    return ConstrainedBox(
      constraints: const BoxConstraints(minWidth: 160, maxWidth: 260),
      child: DropdownButtonFormField<String>(
        isExpanded: true,
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        ),
        items: [
          const DropdownMenuItem<String>(
            value: '',
            child: Text('-'),
          ),
          ...options.map((e) => DropdownMenuItem(value: e, child: Text(e))),
        ],
        value: (value ?? '').isEmpty ? '' : value,
        onChanged: (v) => onChanged((v ?? '').isEmpty ? null : v),
      ),
    );
  }

  Widget _buildNumberField(String label, void Function(String) onChanged) {
    return ConstrainedBox(
      constraints: const BoxConstraints(minWidth: 160, maxWidth: 220),
      child: TextFormField(
        keyboardType: TextInputType.number,
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        ),
        onChanged: onChanged,
        onFieldSubmitted: (_) => _refresh(),
      ),
    );
  }

  Widget _buildResults() {
    if (_rows.isEmpty) {
      return const Center(child: Text('Tidak ada data. Ubah filter atau kata kunci.'));
    }

    return NotificationListener<ScrollNotification>(
      onNotification: (notif) {
        if (notif.metrics.pixels >= notif.metrics.maxScrollExtent - 100) {
          _loadMore();
        }
        return false;
      },
      child: ListView.separated(
        itemCount: _rows.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (context, index) {
          final row = _rows[index];
          final brand = (row['BRAND'] ?? '').toString();
          final model = (row['MODEL'] ?? '').toString();
          final vehicle = (row['VEHICLE'] ?? '').toString();
          final region = (row['REGION'] ?? '').toString();
          final tahun = (row['TAHUN'] ?? '').toString();
          final harga = (row['HARGA_PASAR'] ?? '').toString();
          final desc = (row['OBJECT_DESCRIPTION'] ?? '').toString();

          return ListTile(
            leading: CircleAvatar(child: Text(brand.isNotEmpty ? brand[0] : '?')),
            title: Text('$brand • $model'),
            subtitle: Text('$vehicle • $region • $tahun\n$desc'),
            isThreeLine: true,
            trailing: Text(harga),
            onTap: () {
              showDialog(
                context: context,
                builder: (_) => AlertDialog(
                  title: Text('$brand $model'),
                  content: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _kv('Vehicle', vehicle),
                      _kv('Region', region),
                      _kv('Tahun', tahun),
                      _kv('Harga Pasar', harga),
                      const SizedBox(height: 8),
                      Text(desc),
                    ],
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Tutup'),
                    )
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }

  Widget _kv(String k, String v) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4.0),
      child: Row(
        children: [
          Text('$k: ', style: const TextStyle(fontWeight: FontWeight.bold)),
          Expanded(child: Text(v)),
        ],
      ),
    );
  }
}
