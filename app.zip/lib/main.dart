import 'dart:async';
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'db_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  final dark = prefs.getBool('dark') ?? false;
  final textScale = prefs.getDouble('textScale') ?? 1.0;
  final compact = prefs.getBool('compact') ?? false;
  final seen = prefs.getBool('onboarding_seen') ?? false;
  runApp(OtrRoot(initialDark: dark, initialTextScale: textScale, initialCompact: compact, showOnboarding: !seen));
}

class OtrRoot extends StatefulWidget {
  const OtrRoot({super.key, required this.initialDark, required this.initialTextScale, required this.initialCompact, required this.showOnboarding});
  final bool initialDark;
  final double initialTextScale;
  final bool initialCompact;
  final bool showOnboarding;
  @override
  State<OtrRoot> createState() => _OtrRootState();
}

class _OtrRootState extends State<OtrRoot> {
  final _homeKey = GlobalKey<_HomePageState>();
  late bool _dark = widget.initialDark;
  late double _textScale = widget.initialTextScale;
  late bool _compact = widget.initialCompact;
  late bool _showOnboarding = widget.showOnboarding;

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setBool('dark', _dark);
    await p.setDouble('textScale', _textScale);
    await p.setBool('compact', _compact);
  }

  final List<Map<String, String>> _changelog = const [
    {'version': 'v8.5', 'changes': '- Onboarding wizard (muncul sekali)\n- AppBar minimal (Info & Settings)\n- Sortir pindah ke Settings\n- Infinite scroll guard\n- Network diagnostic & fallback download'},
    {'version': 'v8.3', 'changes': '- Autocomplete keyword, ikon brand, perbaikan UI'},
  ];

  @override
  Widget build(BuildContext context) {
    final theme = ThemeData(
      useMaterial3: true,
      inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
      listTileTheme: ListTileThemeData(
        dense: _compact,
        visualDensity: _compact ? VisualDensity.compact : VisualDensity.standard,
      ),
      dataTableTheme: const DataTableThemeData(columnSpacing: 16.0, headingRowHeight: 44),
    );
    final darkTheme = theme.copyWith(brightness: Brightness.dark);

    final home = HomePage(
      key: _homeKey,
      onOpenSettings: _openSettings,
      onOpenDbInfo: _openDbInfo,
      onOpenSort: _openSortSheet,
    );

    return MaterialApp(
      title: 'Pencarian Data OTR',
      debugShowCheckedModeBanner: false,
      theme: theme,
      darkTheme: darkTheme,
      themeMode: _dark ? ThemeMode.dark : ThemeMode.light,
      builder: (context, child) => MediaQuery(
        data: MediaQuery.of(context).copyWith(textScaleFactor: _textScale),
        child: child!,
      ),
      home: _showOnboarding
          ? OnboardingPage(onFinish: () async {
              final p = await SharedPreferences.getInstance();
              await p.setBool('onboarding_seen', true);
              setState(() => _showOnboarding = false);
            })
          : home,
    );
  }

  void _openSettings(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      showDragHandle: true,
      builder: (_) => StatefulBuilder(
        builder: (context, set) => Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                const Icon(Icons.settings),
                const SizedBox(width: 8),
                const Text('Pengaturan', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                const Spacer(),
                IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close)),
              ]),
              const SizedBox(height: 8),
              ListTile(
                leading: const Icon(Icons.sort),
                title: const Text('Pengurutan'),
                subtitle: const Text('Pilih kolom & arah'),
                onTap: () { Navigator.pop(context); _openSortSheet(context); },
                contentPadding: EdgeInsets.zero,
              ),
              SwitchListTile(
                title: const Text('Dark mode'),
                value: _dark,
                onChanged: (v) => set(() { setState(() => _dark = v); _save(); }),
                secondary: const Icon(Icons.dark_mode),
                contentPadding: EdgeInsets.zero,
              ),
              SwitchListTile(
                title: const Text('Tampilan compact (list lebih rapat)'),
                value: _compact,
                onChanged: (v) => set(() { setState(() => _compact = v); _save(); }),
                secondary: const Icon(Icons.view_agenda_outlined),
                contentPadding: EdgeInsets.zero,
              ),
              const SizedBox(height: 8),
              const Text('Ukuran teks', style: TextStyle(fontWeight: FontWeight.w600)),
              Row(children: [
                const Text('Kecil'),
                Expanded(child: Slider(
                  min: 0.9, max: 1.3, divisions: 8, value: _textScale,
                  onChanged: (v) => set(() { setState(() => _textScale = v); _save(); }),
                )),
                const Text('Besar'),
              ]),
              const SizedBox(height: 8),
              ListTile(
                leading: const Icon(Icons.cloud_download_outlined),
                title: const Text('Update database dari GitHub'),
                subtitle: const Text('Ambil harga terbaru dari repo'),
                onTap: () async {
                  Navigator.pop(context);
                  await _homeKey.currentState?._onUpdateFromGitHub();
                },
                contentPadding: EdgeInsets.zero,
              ),
              ListTile(
                leading: const Icon(Icons.network_check),
                title: const Text('Tes koneksi GitHub'),
                onTap: () async {
                  Navigator.pop(context);
                  final r = await NetworkDiag.testGithubReachability();
                  if (context.mounted) {
                    showDialog(context: context, builder: (_) => AlertDialog(
                      title: const Text('Hasil tes koneksi'),
                      content: Text(r),
                      actions: [TextButton(onPressed: ()=>Navigator.pop(context), child: const Text('OK'))],
                    ));
                  }
                },
                contentPadding: EdgeInsets.zero,
              ),
              ListTile(
                leading: const Icon(Icons.menu_book_outlined),
                title: const Text('Panduan awal'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => OnboardingPage(onFinish: () => Navigator.pop(context)),
                    fullscreenDialog: true,
                  ));
                },
                contentPadding: EdgeInsets.zero,
              ),
              ListTile(
                leading: const Icon(Icons.history),
                title: const Text('Changelog / Riwayat Versi'),
                onTap: () => _openChangelog(context),
                contentPadding: EdgeInsets.zero,
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _openSortSheet(BuildContext context) {
    final options = <String, String>{
      'MODEL': 'Model', 'VEHICLE': 'Vehicle', 'REGION': 'Region',
      'TAHUN': 'Tahun', 'HARGA_PASAR': 'Harga (Rp.)',
      'REVISION': 'Revision (Rp.)', 'BRAND': 'Brand',
    };
    final currentKey = _homeKey.currentState?._orderBy.split(' ').first ?? 'MODEL';
    showModalBottomSheet(
      context: context, useSafeArea: true, showDragHandle: true,
      builder: (_) => StatefulBuilder(
        builder: (ctx, set) => Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('Urutkan berdasarkan', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            ...options.entries.map((e) => RadioListTile<String>(
              value: e.key, groupValue: _homeKey.currentState?._orderBy.split(' ').first ?? currentKey,
              onChanged: (v) {
                final asc = _homeKey.currentState?._sortAsc ?? true;
                _homeKey.currentState?.setState(() {
                  _homeKey.currentState!._orderBy = '$v ${asc ? 'ASC' : 'DESC'}, MODEL ASC, TAHUN ASC';
                });
                Navigator.pop(ctx);
                _homeKey.currentState?._refresh();
              },
              title: Text(e.value),
            )),
            const Divider(),
            SwitchListTile(
              title: const Text('Naik (ASC) / Turun (DESC)'),
              value: _homeKey.currentState?._sortAsc ?? true,
              onChanged: (v) {
                final key = _homeKey.currentState?._orderBy.split(' ').first ?? currentKey;
                _homeKey.currentState?.setState(() {
                  _homeKey.currentState!._sortAsc = v;
                  _homeKey.currentState!._orderBy = '$key ${v ? 'ASC' : 'DESC'}, MODEL ASC, TAHUN ASC';
                });
                Navigator.pop(ctx);
                _homeKey.currentState?._refresh();
              },
            ),
          ]),
        ),
      ),
    );
  }

  void _openChangelog(BuildContext context) {
    showModalBottomSheet(
      context: context, useSafeArea: true, showDragHandle: true,
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        child: ListView.builder(
          itemCount: _changelog.length,
          itemBuilder: (ctx, i) {
            final item = _changelog[i];
            return Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(item['version']!, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Text(item['changes']!, style: const TextStyle(height: 1.4)),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  void _openDbInfo(BuildContext context) async {
    final info = await _homeKey.currentState?.collectDbInfo() ?? {};
    final nf = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp.', decimalDigits: 0);
    showModalBottomSheet(
      context: context, useSafeArea: true, showDragHandle: true,
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Informasi Database', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          _row('Total baris', '${info['rows'] ?? 0}'),
          _row('Rentang tahun', '${info['minYear'] ?? ''} – ${info['maxYear'] ?? ''}'),
          _row('Harga min', nf.format(info['minPrice'] ?? 0)),
          _row('Harga max', nf.format(info['maxPrice'] ?? 0)),
          _row('Jumlah brand', '${info['brands'] ?? 0}'),
          _row('Jumlah region', '${info['regions'] ?? 0}'),
          _row('Max revision', nf.format(info['maxRevision'] ?? 0)),
        ]),
      ),
    );
  }

  Widget _row(String a, String b) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 6),
    child: Row(children: [Expanded(child: Text(a)), Text(b, style: const TextStyle(fontWeight: FontWeight.w600))]),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.onOpenSettings, required this.onOpenDbInfo, required this.onOpenSort});
  final void Function(BuildContext) onOpenSettings;
  final void Function(BuildContext) onOpenDbInfo;
  final void Function(BuildContext) onOpenSort;
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Database? _db;
  bool _loading = true;
  final _searchCtrl = TextEditingController();
  final _searchFocus = FocusNode();
  Timer? _debounce;
  String _keyword = '';
  String? _brand, _region, _tahunMin, _tahunMax;
  RangeValues _hargaRange = const RangeValues(0, 200000000);

  List<String> _suggestions = [];
  bool _showSuggest = false;

  final String _table = 'Sheet1';
  final List<String> _selectColumns = const [
    'BRAND','VEHICLE','MODEL','REGION','TAHUN','HARGA_PASAR',
    'OBJECT_DESCRIPTION','NAMA_CABANG','KODE_CABANG','REVISION','OBJECT_TYPE','GROUP_TYPE_UNIT'
  ];

  List<String> _brands = [], _regions = [], _tahuns = [];
  List<Map<String, Object?>> _rows = [];
  int _limit = 50, _offset = 0; bool _hasMore = true; bool _isLoadingMore = false;

  int? _sortColumnIndex;
  bool _sortAsc = true;
  String _orderBy = 'BRAND ASC, MODEL ASC, TAHUN ASC';

  final _rupiah = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp.', decimalDigits: 0);
  final ScrollController _scroll = ScrollController();

  @override
  void initState() {
    super.initState();
    Intl.defaultLocale = 'id_ID';
    _initDb();
    _scroll.addListener(() {
      if (_scroll.position.pixels >= _scroll.position.maxScrollExtent - 80) _loadMore();
    });
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _scroll.dispose();
    _searchCtrl.dispose();
    _searchFocus.dispose();
    super.dispose();
  }

  Future<void> _initDb() async {
    final db = await DbService.openPreloadedDb();
    final brands = await db.rawQuery('SELECT DISTINCT BRAND FROM $_table WHERE BRAND IS NOT NULL AND TRIM(BRAND) != "" ORDER BY BRAND');
    final regions = await db.rawQuery('SELECT DISTINCT REGION FROM $_table WHERE REGION IS NOT NULL AND TRIM(REGION) != "" ORDER BY REGION');
    final tahuns = await db.rawQuery('SELECT DISTINCT TAHUN FROM $_table WHERE TAHUN IS NOT NULL AND TRIM(TAHUN) != "" ORDER BY TAHUN');
    setState(() {
      _db = db;
      _brands = brands.map((e) => (e['BRAND'] ?? '').toString()).toList();
      _regions = regions.map((e) => (e['REGION'] ?? '').toString()).toList();
      _tahuns = tahuns.map((e) => (e['TAHUN'] ?? '').toString()).toList();
      _loading = false;
    });
    await _refresh();
  }

  Future<void> _refresh() async {
    if (_db == null) return;
    setState(() { _loading = true; _rows = []; _offset = 0; _hasMore = true; });
    final args = <Object?>[]; final where = _buildWhereClause(args);
    final sql = 'SELECT ${_selectColumns.join(', ')} FROM $_table $where ORDER BY $_orderBy LIMIT $_limit OFFSET 0';
    final result = await _db!.rawQuery(sql, args);
    setState(() {
      _rows = result;
      _offset = result.length;
      _hasMore = result.length == _limit;
      _loading = false;
    });
    _searchFocus.requestFocus();
  }

  String _buildWhereClause(List<Object?> argsOut) {
    final parts = <String>[];
    if (_keyword.trim().isNotEmpty) {
      final like = '%${_keyword.trim()}%';
      parts.add('(BRAND LIKE ? OR VEHICLE LIKE ? OR MODEL LIKE ? OR OBJECT_DESCRIPTION LIKE ? OR REGION LIKE ?)');
      argsOut.addAll([like, like, like, like, like]);
    }
    if (_brand?.isNotEmpty == true) { parts.add('BRAND = ?'); argsOut.add(_brand); }
    if (_region?.isNotEmpty == true) { parts.add('REGION = ?'); argsOut.add(_region); }
    if (_tahunMin?.isNotEmpty == true) { parts.add('(CAST(COALESCE(MIN_YEAR, TAHUN) AS INTEGER) >= ?)'); argsOut.add(int.tryParse(_tahunMin!) ?? 0); }
    if (_tahunMax?.isNotEmpty == true) { parts.add('(CAST(COALESCE(MAX_YEAR, TAHUN) AS INTEGER) <= ?)'); argsOut.add(int.tryParse(_tahunMax!) ?? 9999); }
    parts.add('HARGA_PASAR >= ?'); argsOut.add(_hargaRange.start.round());
    parts.add('HARGA_PASAR <= ?'); argsOut.add(_hargaRange.end.round());
    return parts.isEmpty ? '' : 'WHERE ' + parts.join(' AND ');
  }

  Future<void> _loadMore() async {
    if (!_hasMore || _db == null || _isLoadingMore) return;
    _isLoadingMore = true;
    final args = <Object?>[]; final where = _buildWhereClause(args);
    final sql = 'SELECT ${_selectColumns.join(', ')} FROM $_table $where ORDER BY $_orderBy LIMIT $_limit OFFSET $_offset';
    final result = await _db!.rawQuery(sql, args);
    setState(() {
      _rows.addAll(result);
      _offset += result.length;
      _hasMore = result.isNotEmpty && result.length == _limit;
      _isLoadingMore = false;
    });
  }

  String _sanitizeDesc(dynamic v) {
    final s = (v ?? '').toString().trim();
    final reg = RegExp(r'^\\d{4}([^\\S\\r\\n]*(-|/)[^\\S\\r\\n]*\\d{4})?$');
    if (s.isEmpty) return '';
    if (reg.hasMatch(s)) return '';
    return s;
  }

  Future<void> _updateSuggestions(String v) async {
    if (_db == null) return;
    final q = v.trim();
    if (q.isEmpty) {
      setState(() { _suggestions = []; _showSuggest = false; });
      return;
    }
    final like = q.replaceAll('%','').replaceAll('_','') + '%';
    final rows = await _db!.rawQuery('''
      SELECT DISTINCT s FROM (
        SELECT MODEL AS s FROM Sheet1 WHERE MODEL LIKE ?
        UNION SELECT BRAND FROM Sheet1 WHERE BRAND LIKE ?
        UNION SELECT VEHICLE FROM Sheet1 WHERE VEHICLE LIKE ?
        UNION SELECT REGION FROM Sheet1 WHERE REGION LIKE ?
        UNION SELECT OBJECT_DESCRIPTION FROM Sheet1 WHERE OBJECT_DESCRIPTION LIKE ?
      ) WHERE s IS NOT NULL AND TRIM(s) != '' LIMIT 8
    ''', [like, like, like, like, like]);
    setState(() {
      _suggestions = rows.map((e) => (e['s'] ?? '').toString()).where((e) => e.isNotEmpty).toList();
      _showSuggest = _suggestions.isNotEmpty;
    });
  }

  void _onSearchChanged(String v) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 300), () async {
      await _updateSuggestions(v);
      setState(() => _keyword = v);
      _refresh();
    });
  }

  Future<Map<String, dynamic>> collectDbInfo() async {
    if (_db == null) return {};
    final cnt = Sqflite.firstIntValue(await _db!.rawQuery('SELECT COUNT(*) FROM $_table')) ?? 0;
    final minMax = await _db!.rawQuery('SELECT MIN(HARGA_PASAR) AS minp, MAX(HARGA_PASAR) AS maxp FROM $_table');
    final y = await _db!.rawQuery('SELECT MIN(CAST(COALESCE(MIN_YEAR, TAHUN) AS INT)) AS miny, MAX(CAST(COALESCE(MAX_YEAR, TAHUN) AS INT)) AS maxy FROM $_table');
    final brandCnt = Sqflite.firstIntValue(await _db!.rawQuery('SELECT COUNT(DISTINCT BRAND) FROM $_table')) ?? 0;
    final regionCnt = Sqflite.firstIntValue(await _db!.rawQuery('SELECT COUNT(DISTINCT REGION) FROM $_table')) ?? 0;
    final revMax = Sqflite.firstIntValue(await _db!.rawQuery('SELECT MAX(REVISION) FROM $_table')) ?? 0;
    return {
      'rows': cnt, 'minPrice': (minMax.first['minp'] ?? 0), 'maxPrice': (minMax.first['maxp'] ?? 0),
      'minYear': (y.first['miny'] ?? ''), 'maxYear': (y.first['maxy'] ?? ''),
      'brands': brandCnt, 'regions': regionCnt, 'maxRevision': revMax,
    };
  }

  Future<void> _onUpdateFromGitHub() async {
    final conn = await Connectivity().checkConnectivity();
    if (conn == ConnectivityResult.none) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Tidak ada koneksi internet. Coba lagi.')),
        );
      }
      return;
    }
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Mengunduh database dari GitHub...')));
    try {
      await DbService.updateDbFromGitHub();
      await _refresh();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Database berhasil diperbarui!')));
      }
    } catch (e) {
      if (mounted) {
        final msg = e.toString().contains('Failed host lookup')
            ? 'Gagal update: tidak bisa mengakses api.github.com (cek internet/DNS/Wi‑Fi)'
            : 'Gagal update: $e';
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () { _showSuggest = false; FocusScope.of(context).unfocus(); setState(() {}); },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Pencarian Data OTR'),
          actions: [
            IconButton(
              tooltip: 'Info database',
              onPressed: () => widget.onOpenDbInfo(context),
              icon: const Icon(Icons.info_outline),
            ),
            IconButton(
              tooltip: 'Pengaturan',
              onPressed: () => widget.onOpenSettings(context),
              icon: const Icon(Icons.settings),
            ),
          ],
        ),
        body: Column(
          children: [
            _buildSearchRow(),
            const Divider(height: 1),
            if (_loading) const LinearProgressIndicator(minHeight: 2),
            Expanded(child: _buildResults()),
          ],
        ),
      ),
    );
  }

  Widget _buildSearchRow() {
    final border = OutlineInputBorder(borderRadius: BorderRadius.circular(12));
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 6),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: TextField(
                  focusNode: _searchFocus,
                  controller: _searchCtrl,
                  decoration: InputDecoration(
                    labelText: 'Kata kunci (brand/model/vehicle/desc/region)',
                    border: border,
                    prefixIcon: const Icon(Icons.search),
                  ),
                  onChanged: _onSearchChanged,
                  onTap: () { if (_suggestions.isNotEmpty) setState(() => _showSuggest = true); },
                ),
              ),
              const SizedBox(width: 8),
              FilledButton.icon(
                onPressed: _refresh,
                icon: const Icon(Icons.search),
                label: const Text('Cari'),
              ),
            ],
          ),
          if (_showSuggest)
            Container(
              width: double.infinity,
              margin: const EdgeInsets.only(top: 6),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surface,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 8)],
              ),
              child: ListView.separated(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _suggestions.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (_, i) {
                  final s = _suggestions[i];
                  return ListTile(
                    dense: true,
                    title: Text(s, maxLines: 1, overflow: TextOverflow.ellipsis),
                    onTap: () {
                      _searchCtrl.text = s;
                      _keyword = s;
                      _showSuggest = false;
                      setState(() {});
                      _refresh();
                      _searchCtrl.selection = TextSelection.fromPosition(TextPosition(offset: _searchCtrl.text.length));
                    },
                  );
                },
              ),
            ),
        ],
      ),
    );
  }

  ImageProvider _brandIcon(String brand) {
    final b = brand.toLowerCase();
    if (b.contains('yamaha')) return const AssetImage('assets/icons/yamaha.png');
    if (b.contains('honda')) return const AssetImage('assets/icons/honda.png');
    if (b.contains('suzuki')) return const AssetImage('assets/icons/suzuki.png');
    if (b.contains('kawasaki')) return const AssetImage('assets/icons/kawasaki.png');
    if (b.contains('tvs')) return const AssetImage('assets/icons/tvs.png');
    return const AssetImage('assets/icons/default.png');
  }

  Widget _buildResults() {
    if (_rows.isEmpty && !_loading) return const Center(child: Text('Tidak ada data. Ubah filter/kata kunci.'));
    final itemCount = _rows.length + (_hasMore ? 1 : 0);

    return RefreshIndicator(
      onRefresh: _refresh,
      child: ListView.separated(
        controller: _scroll,
        keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
        physics: const AlwaysScrollableScrollPhysics(),
        itemCount: itemCount,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (context, i) {
          if (i >= _rows.length) {
            if (_hasMore) {
              _loadMore();
              return const Padding(
                padding: EdgeInsets.symmetric(vertical: 16),
                child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
              );
            } else {
              return const Padding(
                padding: EdgeInsets.symmetric(vertical: 16),
                child: Center(child: Text('— sudah semua —')),
              );
            }
          }
          final r = _rows[i];
          String h(dynamic v) => _rupiah.format((num.tryParse(v.toString()) ?? 0).round());
          final desc = _sanitizeDesc(r['OBJECT_DESCRIPTION']);
          final brand = (r['BRAND'] ?? '').toString();

          return ListTile(
            leading: CircleAvatar(backgroundImage: _brandIcon(brand)),
            title: Text('${r['MODEL'] ?? ''}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text('${r['VEHICLE'] ?? ''} • ${r['REGION'] ?? ''} • ${r['TAHUN'] ?? ''}${desc.isNotEmpty ? '\n$desc' : ''}', maxLines: 2),
            trailing: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(h(r['HARGA_PASAR']), style: const TextStyle(fontWeight: FontWeight.bold)),
                Text('Rev: ${h(r['REVISION'] ?? 0)}', style: const TextStyle(fontSize: 12)),
              ],
            ),
            onTap: () => _showDetail(r),
          );
        },
      ),
    );
  }

  void _showDetail(Map<String, Object?> r) {
    String h(dynamic v) => _rupiah.format((num.tryParse(v.toString()) ?? 0).round());
    showModalBottomSheet(
      context: context,
      useSafeArea: true,
      isScrollControlled: true,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            CircleAvatar(backgroundImage: _brandIcon((r['BRAND'] ?? '').toString())),
            const SizedBox(width: 12),
            Expanded(child: Text('${r['BRAND'] ?? ''} • ${r['MODEL'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16))),
            Text(h(r['HARGA_PASAR']), style: const TextStyle(fontWeight: FontWeight.bold)),
          ]),
          const SizedBox(height: 12),
          Wrap(spacing: 12, runSpacing: 8, children: [
            _chip('Vehicle', '${r['VEHICLE'] ?? ''}'),
            _chip('Region', '${r['REGION'] ?? ''}'),
            _chip('Tahun', '${r['TAHUN'] ?? ''}'),
            _chip('Revision', h(r['REVISION'] ?? 0)),
            _chip('Cabang', '${r['NAMA_CABANG'] ?? ''} (${r['KODE_CABANG'] ?? ''})'),
            _chip('Type', '${r['OBJECT_TYPE'] ?? ''}'),
            _chip('Group', '${r['GROUP_TYPE_UNIT'] ?? ''}'),
          ]),
          const SizedBox(height: 12),
          if (_sanitizeDesc(r['OBJECT_DESCRIPTION']).isNotEmpty)
            Text(_sanitizeDesc(r['OBJECT_DESCRIPTION']), style: const TextStyle(height: 1.3)),
        ]),
      ),
    );
  }

  Widget _chip(String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.6),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Text('$label: ', style: const TextStyle(fontWeight: FontWeight.w600)),
        Text(value),
      ]),
    );
  }
}

// -------------------- ONBOARDING --------------------
class OnboardingPage extends StatefulWidget {
  const OnboardingPage({super.key, required this.onFinish});
  final VoidCallback onFinish;

  @override
  State<OnboardingPage> createState() => _OnboardingPageState();
}

class _OnboardingPageState extends State<OnboardingPage> {
  final _c = PageController();
  int _i = 0;

  final _pages = const [
    _OnbSlide(
      icon: Icons.search_rounded,
      title: 'Pencarian Data OTR',
      desc: 'Cari cepat brand/model/vehicle/region. Ada saran otomatis & hasil realtime.',
    ),
    _OnbSlide(
      icon: Icons.tune_rounded,
      title: 'Filter & Urutan',
      desc: 'Atur rentang harga, tahun, dan urutan lewat Pengaturan.',
    ),
    _OnbSlide(
      icon: Icons.cloud_download_outlined,
      title: 'Update Database',
      desc: 'Ambil DB terbaru dari GitHub. Lihat Info Database & Changelog.',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final dots = List.generate(_pages.length, (idx) {
      final active = idx == _i;
      return AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        margin: const EdgeInsets.symmetric(horizontal: 4),
        width: active ? 18 : 8,
        height: 8,
        decoration: BoxDecoration(
          color: active ? Theme.of(context).colorScheme.primary : Theme.of(context).colorScheme.outlineVariant,
          borderRadius: BorderRadius.circular(8),
        ),
      );
    });

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(onPressed: widget.onFinish, child: const Text('Lewati')),
            ),
            Expanded(
              child: PageView.builder(
                controller: _c,
                itemCount: _pages.length,
                onPageChanged: (v) => setState(() => _i = v),
                itemBuilder: (_, i) => _pages[i],
              ),
            ),
            const SizedBox(height: 8),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: dots),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _i == 0 ? null : () => _c.previousPage(duration: const Duration(milliseconds: 260), curve: Curves.easeOut),
                      icon: const Icon(Icons.chevron_left),
                      label: const Text('Sebelumnya'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: () {
                        if (_i < _pages.length - 1) {
                          _c.nextPage(duration: const Duration(milliseconds: 260), curve: Curves.easeOut);
                        } else {
                          widget.onFinish();
                        }
                      },
                      icon: Icon(_i < _pages.length - 1 ? Icons.chevron_right : Icons.check),
                      label: Text(_i < _pages.length - 1 ? 'Lanjut' : 'Mulai'),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
}

class _OnbSlide extends StatelessWidget {
  const _OnbSlide({required this.icon, required this.title, required this.desc});
  final IconData icon;
  final String title;
  final String desc;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 120, height: 120,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Theme.of(context).colorScheme.primaryContainer,
            ),
            child: Icon(icon, size: 64, color: Theme.of(context).colorScheme.onPrimaryContainer),
          ),
          const SizedBox(height: 24),
          Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          Text(desc, textAlign: TextAlign.center, style: const TextStyle(height: 1.4)),
        ],
      ),
    );
  }
}
