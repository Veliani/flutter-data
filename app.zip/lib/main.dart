import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'db_service.dart';

const String kAppTitle = 'OTR Lookup';

class ChangelogEntry {
  final String version;
  final String date;
  final List<String> points;
  const ChangelogEntry(this.version, this.date, this.points);
}

const List<ChangelogEntry> kChangelog = [
  ChangelogEntry('Beta V1', '—', [
    'Rilis awal: template Flutter + load DB lokal (.db).',
    'Pencarian sederhana + daftar hasil.',
  ]),
  ChangelogEntry('V2', '—', [
    'Filter: Brand, Region, Tahun min/max, Harga min/max (Rp.).',
    'Perapihan list: judul tebal, layout lebih rapi.',
  ]),
  ChangelogEntry('V3', '—', [
    'Filter bisa di-hide via toggle.',
    'Harga & Rev ditampilkan di list (Rp.).',
    'Cabang disembunyikan di list, tampil di detail.',
  ]),
  ChangelogEntry('V4', '—', [
    'Sorting header di tabel.',
    'Persist tema & ukuran teks.',
    'Slider rentang harga.',
    'Realtime search + detail elegan.',
  ]),
  ChangelogEntry('V5', '—', [
    'Penataan UI: Vehicle • Region • Tahun di baris atas.',
    'Rev pakai Rp., judul item bold.',
    'Menu pengaturan untuk dark/light + slider teks.',
  ]),
  ChangelogEntry('V6', '—', [
    'Perbaikan build & optimasi query; patch string interpolasi.',
  ]),
  ChangelogEntry('V7', '—', [
    'Data summary (Hasil: X dari Y).',
    'Saved search (chip preset).',
    'Compact/Expanded mode.',
    'App bar minimal hanya tombol Pengaturan.',
    'Loading halus (LinearProgressIndicator).',
  ]),
];


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  final dark = prefs.getBool('dark') ?? false;
  final textScale = prefs.getDouble('textScale') ?? 1.0;
  final compact = prefs.getBool('compact') ?? false;
  runApp(OtrRoot(initialDark: dark, initialTextScale: textScale, initialCompact: compact));
}

class OtrRoot extends StatefulWidget {
  const OtrRoot({super.key, required this.initialDark, required this.initialTextScale, required this.initialCompact});
  final bool initialDark;
  final double initialTextScale;
  final bool initialCompact;

  @override
  State<OtrRoot> createState() => _OtrRootState();
}

class _OtrRootState extends State<OtrRoot> {
  late bool _dark = widget.initialDark;
  late double _textScale = widget.initialTextScale;
  late bool _compact = widget.initialCompact;

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('dark', _dark);
    await prefs.setDouble('textScale', _textScale);
    await prefs.setBool('compact', _compact);
  }

  @override
  Widget build(BuildContext context) {
    final light = ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
      useMaterial3: true,
      inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
      dataTableTheme: const DataTableThemeData(columnSpacing: 16.0, headingRowHeight: 44),
    );
    final dark = ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue, brightness: Brightness.dark),
      useMaterial3: true,
      inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
      dataTableTheme: const DataTableThemeData(columnSpacing: 16.0, headingRowHeight: 44),
    );
    return MaterialApp(
      title: kAppTitle,
      debugShowCheckedModeBanner: false,
      theme: light,
      darkTheme: dark,
      themeMode: _dark ? ThemeMode.dark : ThemeMode.light,
      builder: (context, child) => MediaQuery(
        data: MediaQuery.of(context).copyWith(textScaleFactor: _textScale),
        child: child!,
      ),
      home: HomePage(
        onOpenSettings: _openSettings,
        compact: _compact,
      ),
    );
  }

  void _openSettings(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      showDragHandle: true,
      builder: (_) => StatefulBuilder(
        builder: (context, set) => Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.settings),
                  const SizedBox(width: 8),
                  const Text('Pengaturan', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                  const Spacer(),
                  IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close)),
                ],
              ),
              const SizedBox(height: 8),
              SwitchListTile(
                title: const Text('Dark mode'),
                value: _dark,
                onChanged: (v) => set(() { setState(() => _dark = v); _save(); }),
                secondary: const Icon(Icons.dark_mode),
                contentPadding: EdgeInsets.zero,
              ),
              const SizedBox(height: 8),
              const Text('Ukuran teks', style: TextStyle(fontWeight: FontWeight.w600)),
              Row(
                children: [
                  const Text('Kecil'),
                  Expanded(
                    child: Slider(
                      min: 0.9, max: 1.3, divisions: 8,
                      value: _textScale,
                      onChanged: (v) => set(() { setState(() => _textScale = v); _save(); }),
                    ),
                  ),
                  const Text('Besar'),
                ],
              ),
              const Divider(),
              SwitchListTile(
                title: const Text('Compact mode (daftar ringkas)'),
                value: _compact,
                onChanged: (v) => set(() { setState(() => _compact = v); _save(); }),
                secondary: const Icon(Icons.view_agenda_outlined),
                contentPadding: EdgeInsets.zero,
              ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.history),
                title: const Text('Changelog'),
                subtitle: const Text('Ringkasan perubahan dari Beta V1 sampai terbaru'),
                onTap: () { Navigator.pop(context); _openChangelog(context); },
              ),
              const SizedBox(height: 8),
                value: _compact,
                onChanged: (v) => set(() { setState(() => _compact = v); _save(); }),
                secondary: const Icon(Icons.view_agenda_outlined),
                contentPadding: EdgeInsets.zero,
              ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.history),
                title: const Text('Changelog'),
                subtitle: const Text('Ringkasan perubahan dari Beta V1 sampai terbaru'),
                onTap: () { Navigator.pop(context); _openChangelog(context); },
              ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }
  void _openChangelog(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      showDragHandle: true,
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: const [
              Icon(Icons.history),
              SizedBox(width: 8),
              Text('Changelog', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
            ]),
            const SizedBox(height: 12),
            Flexible(
              child: ListView.separated(
                shrinkWrap: true,
                itemCount: kChangelog.length,
                separatorBuilder: (_, __) => const Divider(height: 16),
                itemBuilder: (context, i) {
                  final e = kChangelog[kChangelog.length - 1 - i]; // newest first
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('${e.version} ${e.date}', style: const TextStyle(fontWeight: FontWeight.w700)),
                      const SizedBox(height: 6),
                      ...e.points.map((p) => Row(children: [const Text('• '), Expanded(child: Text(p))])),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

}

class SavedSearch {
  final String keyword;
  final String? brand;
  final String? region;
  final String? tahunMin;
  final String? tahunMax;
  final double hargaMin;
  final double hargaMax;
  const SavedSearch(this.keyword, this.brand, this.region, this.tahunMin, this.tahunMax, this.hargaMin, this.hargaMax);

  Map<String, dynamic> toJson() => {
    'keyword': keyword, 'brand': brand, 'region': region, 'tahunMin': tahunMin, 'tahunMax': tahunMax,
    'hargaMin': hargaMin, 'hargaMax': hargaMax,
  };
  static SavedSearch fromJson(Map<String, dynamic> j) => SavedSearch(
    j['keyword'] ?? '', j['brand'], j['region'], j['tahunMin'], j['tahunMax'],
    (j['hargaMin'] ?? 0).toDouble(), (j['hargaMax'] ?? 200000000).toDouble(),
  );
  String get label {
    final parts = <String>[];
    if (keyword.trim().isNotEmpty) parts.add(keyword.trim());
    if (brand != null && brand!.isNotEmpty) parts.add(brand!);
    if (region != null && region!.isNotEmpty) parts.add(region!);
    if (tahunMin != null && tahunMin!.isNotEmpty) parts.add('≥$tahunMin');
    if (tahunMax != null && tahunMax!.isNotEmpty) parts.add('≤$tahunMax');
    return parts.isEmpty ? 'Preset' : parts.join(' • ');
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.onOpenSettings, required this.compact});
  final void Function(BuildContext context) onOpenSettings;
  final bool compact;
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Database? _db;
  bool _loading = true;
  bool _tableView = false; // hidden toggle via long-press title
  bool _showFilters = false;

  final _searchCtrl = TextEditingController();
  final _searchFocus = FocusNode();
  Timer? _debounce;
  String _keyword = '';
  String? _brand, _region, _tahunMin, _tahunMax;
  RangeValues _hargaRange = const RangeValues(0, 200000000);

  final String _table = 'Sheet1';
  final List<String> _selectColumns = const [
    'BRAND','VEHICLE','MODEL','REGION','TAHUN','HARGA_PASAR',
    'OBJECT_DESCRIPTION','NAMA_CABANG','KODE_CABANG','REVISION','OBJECT_TYPE','GROUP_TYPE_UNIT'
  ];

  List<String> _brands = [], _regions = [], _tahuns = [];
  List<Map<String, Object?>> _rows = [];
  int _limit = 50, _offset = 0; bool _hasMore = true;

  int? _sortColumnIndex; bool _sortAsc = true;
  String _orderBy = 'BRAND ASC, MODEL ASC, TAHUN ASC';

  int _totalCount = 0;
  List<SavedSearch> _presets = [];

  bool get _compact => (context.findAncestorStateOfType<_OtrRootState>()?._compact) ?? widget.compact;

  final _rupiah = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp.', decimalDigits: 0);

  @override
  void initState() {
    super.initState();
    Intl.defaultLocale = 'id_ID';
    _initDb();
    _loadPresets();
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _searchCtrl.dispose();
    _searchFocus.dispose();
    super.dispose();
  }

  Future<void> _initDb() async {
    final db = await DbService.openPreloadedDb();
    final brands = await db.rawQuery('SELECT DISTINCT BRAND FROM $_table WHERE BRAND IS NOT NULL AND TRIM(BRAND) != "" ORDER BY BRAND');
    final regions = await db.rawQuery('SELECT DISTINCT REGION FROM $_table WHERE REGION IS NOT NULL AND TRIM(REGION) != "" ORDER BY REGION');
    final tahuns = await db.rawQuery('SELECT DISTINCT TAHUN FROM $_table WHERE TAHUN IS NOT NULL AND TRIM(TAHUN) != "" ORDER BY TAHUN');
    setState(() {
      _db = db;
      _brands = brands.map((e) => (e['BRAND'] ?? '').toString()).toList();
      _regions = regions.map((e) => (e['REGION'] ?? '').toString()).toList();
      _tahuns = tahuns.map((e) => (e['TAHUN'] ?? '').toString()).toList();
      _loading = false;
    });
    await _refresh();
  }

  Future<void> _refresh() async {
    if (_db == null) return;
    setState(() { _loading = true; _rows = []; _offset = 0; _hasMore = true; });
    await _updateCounts();
    await _loadMore();
    setState(() { _loading = false; });
  }

  Future<void> _updateCounts() async {
    final args = <Object?>[]; final where = _buildWhereClause(args);
    final res = await _db!.rawQuery('SELECT COUNT(*) as c FROM $_table $where', args);
    _totalCount = int.tryParse((res.first['c']).toString()) ?? 0;
  }

  String _buildWhereClause(List<Object?> argsOut) {
    final parts = <String>[];
    if (_keyword.trim().isNotEmpty) {
      final like = '%${_keyword.trim()}%';
      parts.add('(BRAND LIKE ? OR VEHICLE LIKE ? OR MODEL LIKE ? OR OBJECT_DESCRIPTION LIKE ? OR REGION LIKE ?)');
      argsOut.addAll([like, like, like, like, like]);
    }
    if (_brand?.isNotEmpty == true) { parts.add('BRAND = ?'); argsOut.add(_brand); }
    if (_region?.isNotEmpty == true) { parts.add('REGION = ?'); argsOut.add(_region); }
    if (_tahunMin?.isNotEmpty == true) { parts.add('(CAST(COALESCE(MIN_YEAR, TAHUN) AS INTEGER) >= ?)'); argsOut.add(int.tryParse(_tahunMin!) ?? 0); }
    if (_tahunMax?.isNotEmpty == true) { parts.add('(CAST(COALESCE(MAX_YEAR, TAHUN) AS INTEGER) <= ?)'); argsOut.add(int.tryParse(_tahunMax!) ?? 9999); }
    parts.add('HARGA_PASAR >= ?'); argsOut.add(_hargaRange.start.round());
    parts.add('HARGA_PASAR <= ?'); argsOut.add(_hargaRange.end.round());
    return parts.isEmpty ? '' : 'WHERE ' + parts.join(' AND ');
  }

  Future<void> _loadMore() async {
    if (!_hasMore || _db == null) return;
    final args = <Object?>[]; final where = _buildWhereClause(args);
    final sql = 'SELECT ${_selectColumns.join(', ')} FROM $_table $where ORDER BY $_orderBy LIMIT $_limit OFFSET $_offset';
    final result = await _db!.rawQuery(sql, args);
    setState(() {
      _rows.addAll(result);
      _offset += result.length;
      _hasMore = result.length == _limit;
    });
  }

  void _resetFilters() {
    setState(() {
      _keyword = ''; _searchCtrl.clear();
      _brand = null; _region = null; _tahunMin = null; _tahunMax = null;
      _hargaRange = const RangeValues(0, 200000000);
      _orderBy = 'BRAND ASC, MODEL ASC, TAHUN ASC';
      _sortColumnIndex = null; _sortAsc = true;
    });
    _refresh();
    _searchFocus.requestFocus();
  }

  String _sanitizeDesc(dynamic v) {
    final s = (v ?? '').toString().trim();
    final reg = RegExp(r'^\d{4}([^\S\r\n]*(-|/)[^\S\r\n]*\d{4})?$');
    if (s.isEmpty) return '';
    if (reg.hasMatch(s)) return '';
    return s;
  }

  void _onSearchChanged(String v) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 400), () {
      setState(() => _keyword = v);
      _refresh();
      _searchFocus.requestFocus();
    });
  }

  void _applySort(int columnIndex, String sqlKey) {
    setState(() {
      if (_sortColumnIndex == columnIndex) {
        _sortAsc = !_sortAsc;
      } else {
        _sortColumnIndex = columnIndex;
        _sortAsc = true;
      }
      _orderBy = '$sqlKey ${_sortAsc ? 'ASC' : 'DESC'}';
      _orderBy += ', MODEL ASC, TAHUN ASC';
    });
    _refresh();
  }

  Future<void> _loadPresets() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList('presets') ?? [];
    setState(() {
      _presets = raw.map((s) => SavedSearch.fromJson(jsonDecode(s))).toList();
    });
  }

  Future<void> _saveCurrentAsPreset() async {
    final p = SavedSearch(_keyword, _brand, _region, _tahunMin, _tahunMax, _hargaRange.start, _hargaRange.end);
    final prefs = await SharedPreferences.getInstance();
    final list = prefs.getStringList('presets') ?? [];
    final encoded = jsonEncode(p.toJson());
    if (!list.contains(encoded)) {
      list.insert(0, encoded);
      if (list.length > 8) list.removeLast();
      await prefs.setStringList('presets', list);
      await _loadPresets();
    }
  }

  Future<void> _applyPreset(SavedSearch p) async {
    setState(() {
      _keyword = p.keyword; _searchCtrl.text = p.keyword;
      _brand = p.brand; _region = p.region; _tahunMin = p.tahunMin; _tahunMax = p.tahunMax;
      _hargaRange = RangeValues(p.hargaMin, p.hargaMax);
    });
    await _refresh();
  }

  Future<void> _deletePreset(SavedSearch p) async {
    final prefs = await SharedPreferences.getInstance();
    final list = prefs.getStringList('presets') ?? [];
    final encoded = jsonEncode(p.toJson());
    list.remove(encoded);
    await prefs.setStringList('presets', list);
    await _loadPresets();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: GestureDetector(
          onLongPress: () => setState(() => _tableView = !_tableView), // hidden toggle
          child: const Text(kAppTitle),
        ),
        actions: [
          IconButton(
            tooltip: 'Pengaturan',
            onPressed: () => (context.findAncestorStateOfType<_OtrRootState>()?._openSettings(context)),
            icon: const Icon(Icons.settings),
          ),
        ],
      ),
      body: Column(
        children: [
          _buildSearchRow(),
          if (_showFilters) _buildFilters(context),
          if (_loading) const LinearProgressIndicator(minHeight: 2),
          _buildPresetsChips(),
          _buildSummaryBar(),
          const Divider(height: 1),
          Expanded(child: _tableView ? _buildTable() : _buildResults()),
        ],
      ),
    );
  }

  Widget _buildSearchRow() {
    final border = OutlineInputBorder(borderRadius: BorderRadius.circular(12));
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 6),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              focusNode: _searchFocus,
              controller: _searchCtrl,
              decoration: InputDecoration(
                labelText: 'Kata kunci (brand/model/vehicle/desc/region)',
                border: border,
                prefixIcon: const Icon(Icons.search),
              ),
              onChanged: _onSearchChanged,
            ),
          ),
          const SizedBox(width: 8),
          IconButton(
            tooltip: _showFilters ? 'Sembunyikan filter' : 'Tampilkan filter',
            onPressed: () => setState(() => _showFilters = !_showFilters),
            icon: const Icon(Icons.tune),
          ),
          const SizedBox(width: 4),
          FilledButton(onPressed: _saveCurrentAsPreset, child: const Text('Simpan')),
        ],
      ),
    );
  }

  Widget _buildPresetsChips() {
    if (_presets.isEmpty) return const SizedBox.shrink();
    return SizedBox(
      height: 44,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        scrollDirection: Axis.horizontal,
        itemCount: _presets.length,
        itemBuilder: (_, i) {
          final p = _presets[i];
          return InputChip(
            label: Text(p.label, overflow: TextOverflow.ellipsis),
            onPressed: () => _applyPreset(p),
            onDeleted: () => _deletePreset(p),
            deleteIcon: const Icon(Icons.close),
          );
        },
        separatorBuilder: (_, __) => const SizedBox(width: 8),
      ),
    );
  }

  Widget _buildSummaryBar() {
    final displayed = _rows.length;
    if (displayed == 0 && !_loading) {
      return const Padding(
        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        child: Align(alignment: Alignment.centerLeft, child: Text('Tidak ada hasil. Ubah filter/kata kunci.')),
      );
    }
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 4),
      child: Row(
        children: [
          Text('Hasil: ${displayed.clamp(0, _totalCount)} dari $_totalCount', style: const TextStyle(fontWeight: FontWeight.w600)),
          const Spacer(),
          TextButton(onPressed: _resetFilters, child: const Text('Reset')),
        ],
      ),
    );
  }

  Widget _buildFilters(BuildContext context) {
    return LayoutBuilder(
      builder: (context, c) {
        final twoCols = c.maxWidth > 520;
        final gap = const SizedBox(width: 8, height: 8);
        Widget row(List<Widget> children) => twoCols
            ? Row(children: [Expanded(child: children[0]), const SizedBox(width: 8), Expanded(child: children[1])])
            : Column(children: [children[0], gap, children[1]]);

        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          child: Column(
            children: [
              row([ _dd('Brand', _brands, _brand, (v) => setState(() => _brand = v)),
                    _dd('Region', _regions, _region, (v) => setState(() => _region = v)), ]),
              const SizedBox(height: 8),
              row([ _dd('Tahun min', _tahuns, _tahunMin, (v) => setState(() => _tahunMin = v)),
                    _dd('Tahun max', _tahuns, _tahunMax, (v) => setState(() => _tahunMax = v)), ]),
              const SizedBox(height: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Text('Rentang harga (Rp.)', style: TextStyle(fontWeight: FontWeight.w600)),
                      const SizedBox(width: 8),
                      Text('${_rupiah.format(_hargaRange.start)} - ${_rupiah.format(_hargaRange.end)}', style: const TextStyle(fontSize: 12)),
                    ],
                  ),
                  RangeSlider(
                    values: _hargaRange,
                    min: 0,
                    max: 200000000,
                    divisions: 200,
                    onChanged: (v) => setState(() => _hargaRange = v),
                    onChangeEnd: (v) => _refresh(),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _dd(String label, List<String> options, String? value, void Function(String?) onChanged) {
    return DropdownButtonFormField<String>(
      isExpanded: true,
      decoration: InputDecoration(labelText: label, contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8)),
      items: [const DropdownMenuItem(value: '', child: Text('-')),
        ...options.map((e) => DropdownMenuItem(value: e, child: Text(e)))],
      value: (value ?? '').isEmpty ? '' : value,
      onChanged: (v) { onChanged((v ?? '').isEmpty ? null : v); _refresh(); },
    );
  }

  Widget _buildResults() {
    if (_rows.isEmpty) return const Center(child: Text(''));
    return NotificationListener<ScrollNotification>(
      onNotification: (n) { if (n.metrics.pixels >= n.metrics.maxScrollExtent - 100) _loadMore(); return false; },
      child: ListView.separated(
        itemCount: _rows.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (context, i) {
          final r = _rows[i];
          String h(dynamic v) => _rupiah.format((num.tryParse(v.toString()) ?? 0).round());
          final desc = _sanitizeDesc(r['OBJECT_DESCRIPTION']);
          final title = Text('${r['MODEL'] ?? ''}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700));
          final lineTop = '${r['VEHICLE'] ?? ''} • ${r['REGION'] ?? ''} • ${r['TAHUN'] ?? ''}';
          final trailing = Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(h(r['HARGA_PASAR']), style: const TextStyle(fontWeight: FontWeight.bold)),
              Text('Rev: ${h(r['REVISION'] ?? 0)}', style: const TextStyle(fontSize: 12)),
            ],
          );
          return ListTile(
            dense: _compact,
            minVerticalPadding: _compact ? 4 : null,
            leading: _compact ? null : CircleAvatar(child: Text(((r['BRAND'] ?? '') as String).isNotEmpty ? (r['BRAND'] as String)[0] : '?')),
            title: title,
            subtitle: _compact ? Text(lineTop, maxLines: 1) : Text('$lineTop${desc.isNotEmpty ? '\n$desc' : ''}', maxLines: 2),
            trailing: trailing,
            onTap: () => _showDetail(r),
          );
        },
      ),
    );
  }

  void _showDetail(Map<String, Object?> r) {
    String h(dynamic v) => _rupiah.format((num.tryParse(v.toString()) ?? 0).round());
    showModalBottomSheet(
      context: context,
      useSafeArea: true,
      isScrollControlled: true,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(child: Text(((r['BRAND'] ?? '') as String).isNotEmpty ? (r['BRAND'] as String)[0] : '?')),
                const SizedBox(width: 12),
                Expanded(child: Text('${r['BRAND'] ?? ''} • ${r['MODEL'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16))),
                Text(h(r['HARGA_PASAR']), style: const TextStyle(fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(height: 12),
            Wrap(spacing: 12, runSpacing: 8, children: [
              _chip('Vehicle', '${r['VEHICLE'] ?? ''}'),
              _chip('Region', '${r['REGION'] ?? ''}'),
              _chip('Tahun', '${r['TAHUN'] ?? ''}'),
              _chip('Revision', h(r['REVISION'] ?? 0)),
              _chip('Cabang', '${r['NAMA_CABANG'] ?? ''} (${r['KODE_CABANG'] ?? ''})'),
              _chip('Type', '${r['OBJECT_TYPE'] ?? ''}'),
              _chip('Group', '${r['GROUP_TYPE_UNIT'] ?? ''}'),
            ]),
            const SizedBox(height: 12),
            if (_sanitizeDesc(r['OBJECT_DESCRIPTION']).isNotEmpty)
              Text(_sanitizeDesc(r['OBJECT_DESCRIPTION']), style: const TextStyle(height: 1.3)),
          ],
        ),
      ),
    );
  }

  Widget _chip(String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.6),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Text('$label: ', style: const TextStyle(fontWeight: FontWeight.w600)),
        Text(value),
      ]),
    );
  }

  Widget _buildTable() {
    if (_rows.isEmpty) return const Center(child: Text('Tidak ada data.'));
    final columns = <DataColumn>[
      DataColumn(label: const Text('MODEL'), onSort: (i, _) => _applySort(i, 'MODEL')),
      DataColumn(label: const Text('VEHICLE'), onSort: (i, _) => _applySort(i, 'VEHICLE')),
      DataColumn(label: const Text('REGION'), onSort: (i, _) => _applySort(i, 'REGION')),
      DataColumn(label: const Text('TAHUN'), onSort: (i, _) => _applySort(i, 'TAHUN'), numeric: true),
      DataColumn(label: const Text('HARGA (Rp.)'), onSort: (i, _) => _applySort(i, 'HARGA_PASAR'), numeric: true),
      DataColumn(label: const Text('REV (Rp.)'), onSort: (i, _) => _applySort(i, 'REVISION'), numeric: true),
      DataColumn(label: const Text('BRAND'), onSort: (i, _) => _applySort(i, 'BRAND')),
      DataColumn(label: const Text('TYPE'), onSort: (i, _) => _applySort(i, 'OBJECT_TYPE')),
      DataColumn(label: const Text('GROUP'), onSort: (i, _) => _applySort(i, 'GROUP_TYPE_UNIT')),
    ];

    List<DataRow> rows = _rows.map((r) {
      String harga = _rupiah.format((num.tryParse((r['HARGA_PASAR'] ?? '0').toString()) ?? 0).round());
      String rev = _rupiah.format((num.tryParse((r['REVISION'] ?? '0').toString()) ?? 0).round());
      return DataRow(cells: [
        DataCell(SizedBox(width: 160, child: Text('${r['MODEL'] ?? ''}', overflow: TextOverflow.ellipsis))),
        DataCell(SizedBox(width: 140, child: Text('${r['VEHICLE'] ?? ''}', overflow: TextOverflow.ellipsis))),
        DataCell(SizedBox(width: 140, child: Text('${r['REGION'] ?? ''}', overflow: TextOverflow.ellipsis))),
        DataCell(Text('${r['TAHUN'] ?? ''}')),
        DataCell(Text(harga)),
        DataCell(Text(rev)),
        DataCell(SizedBox(width: 110, child: Text('${r['BRAND'] ?? ''}', overflow: TextOverflow.ellipsis))),
        DataCell(SizedBox(width: 120, child: Text('${r['OBJECT_TYPE'] ?? ''}', overflow: TextOverflow.ellipsis))),
        DataCell(SizedBox(width: 140, child: Text('${r['GROUP_TYPE_UNIT'] ?? ''}', overflow: TextOverflow.ellipsis))),
      ]);
    }).toList();

    return NotificationListener<ScrollNotification>(
      onNotification: (n) { if (n.metrics.pixels >= n.metrics.maxScrollExtent - 100) _loadMore(); return false; },
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          sortColumnIndex: _sortColumnIndex,
          sortAscending: _sortAsc,
          columns: columns,
          rows: rows,
        ),
      ),
    );
  }
}
