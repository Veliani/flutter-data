
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'db_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  runApp(OtrApp(
    initialDark: prefs.getBool('dark') ?? false,
    initialTextScale: prefs.getDouble('textScale') ?? 1.0,
    initialCompact: prefs.getBool('compact') ?? false,
  ));
}

class OtrApp extends StatefulWidget {
  const OtrApp({super.key, required this.initialDark, required this.initialTextScale, required this.initialCompact});
  final bool initialDark;
  final double initialTextScale;
  final bool initialCompact;

  @override
  State<OtrApp> createState() => _OtrAppState();
}

class _OtrAppState extends State<OtrApp> {
  late bool _dark = widget.initialDark;
  late double _textScale = widget.initialTextScale;
  late bool _compact = widget.initialCompact;

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setBool('dark', _dark);
    await p.setDouble('textScale', _textScale);
    await p.setBool('compact', _compact);
  }

  @override
  Widget build(BuildContext context) {
    final lightScheme = ColorScheme.fromSeed(seedColor: Colors.indigo, brightness: Brightness.light);
    final darkScheme  = ColorScheme.fromSeed(seedColor: Colors.indigo, brightness: Brightness.dark);
    final density = _compact ? VisualDensity.compact : VisualDensity.standard;

    final theme = ThemeData(
      useMaterial3: true,
      colorScheme: lightScheme,
      inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
      listTileTheme: ListTileThemeData(visualDensity: density),
    );
    final darkTheme = ThemeData(
      useMaterial3: true,
      colorScheme: darkScheme,
      inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
      listTileTheme: ListTileThemeData(visualDensity: density),
    );

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Pencarian Data OTR',
      theme: theme,
      darkTheme: darkTheme,
      themeMode: _dark ? ThemeMode.dark : ThemeMode.light,
      builder: (context, child) => MediaQuery(
        data: MediaQuery.of(context).copyWith(textScaleFactor: _textScale),
        child: child!,
      ),
      home: HomePage(
        onOpenSettings: _openSettings,
      ),
    );
  }

  void _openSettings(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      showDragHandle: true,
      builder: (_) => StatefulBuilder(
        builder: (context, set) => Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            SwitchListTile(
              title: const Text('Dark mode'),
              value: _dark,
              onChanged: (v){ set((){ setState(()=>_dark=v); _save(); }); },
              secondary: const Icon(Icons.dark_mode),
            ),
            SwitchListTile(
              title: const Text('Tampilan compact'),
              value: _compact,
              onChanged: (v){ set((){ setState(()=>_compact=v); _save(); }); },
              secondary: const Icon(Icons.view_agenda_outlined),
            ),
            Row(children:[
              const Text('Ukuran teks'), const SizedBox(width: 8),
              Expanded(child: Slider(min:0.9,max:1.3,divisions:8,value:_textScale,
                onChanged:(v){ set((){ setState(()=>_textScale=v); _save(); }); })),
            ]),
            const SizedBox(height: 6),
            ListTile(
              leading: const Icon(Icons.cloud_download_outlined),
              title: const Text('Update database dari GitHub'),
              onTap: () async {
                Navigator.pop(context);
                await HomePage.updateDbFromGitHub(context);
              },
            ),
          ]),
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.onOpenSettings});
  final void Function(BuildContext) onOpenSettings;

  static Future<void> updateDbFromGitHub(BuildContext context) async {
    try {
      final conn = await Connectivity().checkConnectivity();
      if (conn == ConnectivityResult.none) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Tidak ada koneksi internet.')));
        return;
      }
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Mengunduh database...')));
      await DbService.updateDbFromGitHub();
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Database diperbarui.')));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal update: $e')));
    }
  }

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Database? _db;
  bool _loading = true;
  final _searchCtrl = TextEditingController();
  final _scroll = ScrollController();
  Timer? _debounce;

  String _keyword = '';
  final String _table = 'Sheet1';
  final List<String> _cols = const [
    'BRAND','VEHICLE','MODEL','REGION','TAHUN','HARGA_PASAR',
    'OBJECT_DESCRIPTION','NAMA_CABANG','KODE_CABANG','REVISION','OBJECT_TYPE','GROUP_TYPE_UNIT'
  ];
  List<Map<String,Object?>> _rows = [];
  int _limit = 50, _offset = 0;
  bool _hasMore = true, _isLoadingMore = false;

  final _rupiah = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp.', decimalDigits: 0);

  @override
  void initState() {
    super.initState();
    Intl.defaultLocale = 'id_ID';
    _initDb();
    _scroll.addListener(() {
      if (_scroll.position.pixels >= _scroll.position.maxScrollExtent - 80) {
        _loadMore();
      }
    });
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _scroll.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _initDb() async {
    _db = await DbService.openPreloadedDb();
    setState(()=>_loading=false);
    await _refresh();
  }

  String _where(List<Object?> argsOut) {
    final parts = <String>[];
    if (_keyword.trim().isNotEmpty) {
      final like = '%${_keyword.trim()}%';
      parts.add('(BRAND LIKE ? OR VEHICLE LIKE ? OR MODEL LIKE ? OR REGION LIKE ? OR OBJECT_DESCRIPTION LIKE ?)');
      argsOut.addAll([like,like,like,like,like]);
    }
    return parts.isEmpty ? '' : 'WHERE ' + parts.join(' AND ');
  }

  Future<void> _refresh() async {
    if (_db == null) return;
    setState((){ _loading=true; _rows=[]; _offset=0; _hasMore=true; });
    final args=<Object?>[]; final where=_where(args);
    final sql='SELECT ${_cols.join(', ')} FROM $_table $where ORDER BY MODEL ASC, TAHUN ASC LIMIT $_limit OFFSET 0';
    final res=await _db!.rawQuery(sql, args);
    setState((){
      _rows=res; _offset=res.length; _hasMore=res.length==_limit; _loading=false;
    });
  }

  Future<void> _loadMore() async {
    if (!_hasMore || _db==null || _isLoadingMore) return;
    setState(()=>_isLoadingMore=true);
    try {
      final args=<Object?>[]; final where=_where(args);
      final sql='SELECT ${_cols.join(', ')} FROM $_table $where ORDER BY MODEL ASC, TAHUN ASC LIMIT $_limit OFFSET $_offset';
      final res=await _db!.rawQuery(sql, args);
      setState((){
        _rows.addAll(res); _offset+=res.length; _hasMore=res.length==_limit;
      });
    } catch (e) {
      if (mounted) {
        _hasMore=false;
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Load lebih gagal: $e')));
      }
    } finally {
      if (mounted) setState(()=>_isLoadingMore=false);
    }
  }

  void _onSearchChanged(String v) {
    _debounce?.cancel();
    _debounce=Timer(const Duration(milliseconds: 300), (){
      setState(()=>_keyword=v);
      _refresh();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pencarian Data OTR'),
        actions: [
          IconButton(icon: const Icon(Icons.settings), onPressed: ()=>widget.onOpenSettings(context)),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12,10,12,6),
            child: Row(children:[
              Expanded(child: TextField(
                controller: _searchCtrl,
                decoration: const InputDecoration(
                  labelText: 'Kata kunci (brand/model/vehicle/desc/region)',
                  prefixIcon: Icon(Icons.search),
                ),
                onChanged: _onSearchChanged,
              )),
              const SizedBox(width:8),
              FilledButton.icon(onPressed: _refresh, icon: const Icon(Icons.search), label: const Text('Cari')),
            ]),
          ),
          const Divider(height:1),
          if (_loading) const LinearProgressIndicator(minHeight:2),
          Expanded(child: _buildList()),
        ],
      ),
    );
  }

  ImageProvider _brandIcon(String brand) {
    final b = brand.toLowerCase();
    if (b.contains('yamaha')) return const AssetImage('assets/icons/yamaha.png');
    if (b.contains('honda')) return const AssetImage('assets/icons/honda.png');
    if (b.contains('suzuki')) return const AssetImage('assets/icons/suzuki.png');
    if (b.contains('kawasaki')) return const AssetImage('assets/icons/kawasaki.png');
    if (b.contains('tvs')) return const AssetImage('assets/icons/tvs.png');
    return const AssetImage('assets/icons/default.png');
  }

  Widget _buildList(){
    final itemCount=_rows.length+(_hasMore?1:0);
    return RefreshIndicator(
      onRefresh: _refresh,
      child: ListView.separated(
        controller: _scroll,
        itemCount: itemCount,
        separatorBuilder: (_, __)=>const Divider(height:1),
        itemBuilder: (context,i){
          if (i>=_rows.length){
            if (_hasMore){
              _loadMore();
              return const Padding(
                padding: EdgeInsets.symmetric(vertical:16),
                child: Center(child: CircularProgressIndicator(strokeWidth:2)),
              );
            }
            return const SizedBox.shrink();
          }
          final r=_rows[i];
          String h(dynamic v)=>_rupiah.format((num.tryParse(v.toString())??0).round());
          final desc=(r['OBJECT_DESCRIPTION']??'').toString().trim();
          final showDesc = desc.isNotEmpty && !RegExp(r'^\\d{4}(\\s*(-|/)\\s*\\d{4})?$').hasMatch(desc);
          return ListTile(
            leading: CircleAvatar(backgroundImage:_brandIcon((r['BRAND']??'').toString())),
            title: Text('${r['MODEL']??''}', style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text('${r['VEHICLE']??''} • ${r['REGION']??''} • ${r['TAHUN']??''}${showDesc?'\n$desc':''}', maxLines: 2),
            trailing: Column(crossAxisAlignment: CrossAxisAlignment.end, mainAxisAlignment: MainAxisAlignment.center, children: [
              Text(h(r['HARGA_PASAR']), style: const TextStyle(fontWeight: FontWeight.bold)),
              Text('Rev: ${h(r['REVISION']??0)}', style: const TextStyle(fontSize: 12)),
            ]),
          );
        },
      ),
    );
  }
}
