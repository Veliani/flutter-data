import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:intl/intl.dart';
import 'db_service.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const OtrApp());
}

class OtrApp extends StatelessWidget {
  const OtrApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pencarian Data OTR',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
        inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Database? _db;
  bool _loading = true;
  bool _tableView = false;

  // Filters
  String _keyword = '';
  String? _brand;
  String? _region;
  String? _cabang;
  String? _tahunMin;
  String? _tahunMax;
  int? _hargaMin;
  int? _hargaMax;

  final String _table = 'Sheet1';

  final List<String> _selectColumns = const [
    'BRAND','VEHICLE','MODEL','REGION','TAHUN','HARGA_PASAR',
    'OBJECT_DESCRIPTION','NAMA_CABANG','KODE_CABANG','REVISION','OBJECT_TYPE','GROUP_TYPE_UNIT'
  ];

  List<String> _brands = [];
  List<String> _regions = [];
  List<String> _cabangs = [];
  List<String> _tahuns = [];

  List<Map<String, Object?>> _rows = [];
  int _limit = 50;
  int _offset = 0;
  bool _hasMore = true;

  final _rupiah = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp', decimalDigits: 0);

  @override
  void initState() {
    super.initState();
    Intl.defaultLocale = 'id_ID';
    _initDb();
  }

  Future<void> _initDb() async {
    final db = await DbService.openPreloadedDb();
    final brands = await db.rawQuery('SELECT DISTINCT BRAND FROM $_table WHERE BRAND IS NOT NULL AND TRIM(BRAND) != "" ORDER BY BRAND');
    final regions = await db.rawQuery('SELECT DISTINCT REGION FROM $_table WHERE REGION IS NOT NULL AND TRIM(REGION) != "" ORDER BY REGION');
    final cabangs = await db.rawQuery('SELECT DISTINCT NAMA_CABANG FROM $_table WHERE NAMA_CABANG IS NOT NULL AND TRIM(NAMA_CABANG) != "" ORDER BY NAMA_CABANG');
    final tahuns = await db.rawQuery('SELECT DISTINCT TAHUN FROM $_table WHERE TAHUN IS NOT NULL AND TRIM(TAHUN) != "" ORDER BY TAHUN');

    setState(() {
      _db = db;
      _brands = brands.map((e) => (e['BRAND'] ?? '').toString()).toList();
      _regions = regions.map((e) => (e['REGION'] ?? '').toString()).toList();
      _cabangs = cabangs.map((e) => (e['NAMA_CABANG'] ?? '').toString()).toList();
      _tahuns = tahuns.map((e) => (e['TAHUN'] ?? '').toString()).toList();
      _loading = false;
    });

    await _refresh();
  }

  Future<void> _refresh() async {
    if (_db == null) return;
    setState(() {
      _loading = true;
      _rows = [];
      _offset = 0;
      _hasMore = true;
    });
    await _loadMore();
    setState(() {
      _loading = false;
    });
  }

  String _buildWhereClause(List<Object?> argsOut) {
    final List<String> parts = [];
    if (_keyword.trim().isNotEmpty) {
      final like = '%${_keyword.trim()}%';
      parts.add('('
          'BRAND LIKE ? OR VEHICLE LIKE ? OR MODEL LIKE ? OR OBJECT_DESCRIPTION LIKE ? OR REGION LIKE ? OR NAMA_CABANG LIKE ? OR KODE_CABANG LIKE ?'
          ')');
      argsOut.addAll([like, like, like, like, like, like, like]);
    }
    if (_brand != null && _brand!.isNotEmpty) {
      parts.add('BRAND = ?');
      argsOut.add(_brand);
    }
    if (_region != null && _region!.isNotEmpty) {
      parts.add('REGION = ?');
      argsOut.add(_region);
    }
    if (_cabang != null && _cabang!.isNotEmpty) {
      parts.add('NAMA_CABANG = ?');
      argsOut.add(_cabang);
    }
    if (_tahunMin != null && _tahunMin!.isNotEmpty) {
      parts.add('(CAST(COALESCE(MIN_YEAR, TAHUN) AS INTEGER) >= ?)');
      argsOut.add(int.tryParse(_tahunMin!) ?? 0);
    }
    if (_tahunMax != null && _tahunMax!.isNotEmpty) {
      parts.add('(CAST(COALESCE(MAX_YEAR, TAHUN) AS INTEGER) <= ?)');
      argsOut.add(int.tryParse(_tahunMax!) ?? 9999);
    }
    if (_hargaMin != null) {
      parts.add('HARGA_PASAR >= ?');
      argsOut.add(_hargaMin);
    }
    if (_hargaMax != null) {
      parts.add('HARGA_PASAR <= ?');
      argsOut.add(_hargaMax);
    }
    return parts.isEmpty ? '' : 'WHERE ' + parts.join(' AND ');
  }

  Future<void> _loadMore() async {
    if (!_hasMore || _db == null) return;
    final List<Object?> args = [];
    final whereClause = _buildWhereClause(args);
    final sql = 'SELECT ${_selectColumns.join(', ')} FROM $_table $whereClause '
        'ORDER BY BRAND, MODEL, TAHUN LIMIT $_limit OFFSET $_offset';
    final result = await _db!.rawQuery(sql, args);
    setState(() {
      _rows.addAll(result);
      _offset += result.length;
      _hasMore = result.length == _limit;
    });
  }

  void _resetFilters() {
    setState(() {
      _keyword = '';
      _brand = null;
      _region = null;
      _cabang = null;
      _tahunMin = null;
      _tahunMax = null;
      _hargaMin = null;
      _hargaMax = null;
    });
    _refresh();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pencarian Data OTR'),
        actions: [
          IconButton(
            tooltip: 'Table/List view',
            onPressed: () => setState(() => _tableView = !_tableView),
            icon: Icon(_tableView ? Icons.view_list : Icons.table_chart),
          ),
          IconButton(
            tooltip: 'Reset filter',
            onPressed: _resetFilters,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                _buildFilters(context),
                const Divider(height: 1),
                Expanded(child: _tableView ? _buildTable() : _buildResults()),
              ],
            ),
    );
  }

  Widget _buildFilters(BuildContext context) {
    final inputBorder = OutlineInputBorder(borderRadius: BorderRadius.circular(12));
    return Padding(
      padding: const EdgeInsets.all(12.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: TextField(
                  decoration: InputDecoration(
                    labelText: 'Kata kunci (brand/model/vehicle/desc/region/cabang)',
                    border: inputBorder,
                    prefixIcon: const Icon(Icons.search),
                  ),
                  onSubmitted: (v) {
                    setState(() => _keyword = v);
                    _refresh();
                  },
                ),
              ),
              const SizedBox(width: 8),
              FilledButton.icon(
                onPressed: _refresh,
                icon: const Icon(Icons.tune),
                label: const Text('Cari'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _buildDropdown('Brand', _brands, _brand, (v) => setState(() => _brand = v)),
              _buildDropdown('Region', _regions, _region, (v) => setState(() => _region = v)),
              _buildDropdown('Cabang', _cabangs, _cabang, (v) => setState(() => _cabang = v)),
              _buildDropdown('Tahun min', _tahuns, _tahunMin, (v) => setState(() => _tahunMin = v)),
              _buildDropdown('Tahun max', _tahuns, _tahunMax, (v) => setState(() => _tahunMax = v)),
              _buildNumberField('Harga min (Rp)', (v) => _hargaMin = v.isEmpty ? null : int.tryParse(v)),
              _buildNumberField('Harga max (Rp)', (v) => _hargaMax = v.isEmpty ? null : int.tryParse(v)),
            ],
          ),
          const SizedBox(height: 6),
          _buildActiveFilters(),
        ],
      ),
    );
  }

  Widget _buildActiveFilters() {
    final chips = <Widget>[];
    void addChip(String label, void Function() onClear) {
      chips.add(Padding(
        padding: const EdgeInsets.only(right: 6),
        child: InputChip(
          label: Text(label),
          onDeleted: onClear,
        ),
      ));
    }

    if (_keyword.isNotEmpty) addChip('Cari: $_keyword', () { setState(() => _keyword = ''); _refresh(); });
    if (_brand != null) addChip('Brand: $_brand', () { setState(() => _brand = null); _refresh(); });
    if (_region != null) addChip('Region: $_region', () { setState(() => _region = null); _refresh(); });
    if (_cabang != null) addChip('Cabang: $_cabang', () { setState(() => _cabang = null); _refresh(); });
    if (_tahunMin != null) addChip('≥ Tahun ${_tahunMin!}', () { setState(() => _tahunMin = null); _refresh(); });
    if (_tahunMax != null) addChip('≤ Tahun ${_tahunMax!}', () { setState(() => _tahunMax = null); _refresh(); });
    if (_hargaMin != null) addChip('≥ ${_rupiah.format(_hargaMin)}', () { setState(() => _hargaMin = null); _refresh(); });
    if (_hargaMax != null) addChip('≤ ${_rupiah.format(_hargaMax)}', () { setState(() => _hargaMax = null); _refresh(); });

    if (chips.isEmpty) return const SizedBox.shrink();
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(children: chips),
    );
  }

  Widget _buildDropdown(String label, List<String> options, String? value, void Function(String?) onChanged) {
    return ConstrainedBox(
      constraints: const BoxConstraints(minWidth: 160, maxWidth: 260),
      child: DropdownButtonFormField<String>(
        isExpanded: true,
        decoration: InputDecoration(
          labelText: label,
          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        ),
        items: [
          const DropdownMenuItem<String>(value: '', child: Text('-')),
          ...options.map((e) => DropdownMenuItem(value: e, child: Text(e))),
        ],
        value: (value ?? '').isEmpty ? '' : value,
        onChanged: (v) => onChanged((v ?? '').isEmpty ? null : v),
      ),
    );
  }

  Widget _buildNumberField(String label, void Function(String) onChanged) {
    return ConstrainedBox(
      constraints: const BoxConstraints(minWidth: 160, maxWidth: 220),
      child: TextFormField(
        keyboardType: TextInputType.number,
        decoration: InputDecoration(labelText: label, contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8)),
        onChanged: onChanged,
        onFieldSubmitted: (_) => _refresh(),
      ),
    );
  }

  Widget _buildResults() {
    if (_rows.isEmpty) {
      return const Center(child: Text('Tidak ada data. Ubah filter atau kata kunci.'));
    }

    return NotificationListener<ScrollNotification>(
      onNotification: (notif) {
        if (notif.metrics.pixels >= notif.metrics.maxScrollExtent - 100) {
          _loadMore();
        }
        return false;
      },
      child: ListView.separated(
        itemCount: _rows.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (context, index) {
          final row = _rows[index];
          String fmtHarga(dynamic v) => _rupiah.format((num.tryParse(v.toString()) ?? 0).round());
          final harga = fmtHarga(row['HARGA_PASAR']);

          return ListTile(
            leading: CircleAvatar(child: Text(((row['BRAND'] ?? '') as String).isNotEmpty ? (row['BRAND'] as String)[0] : '?')),
            title: Text('${row['MODEL'] ?? ''}'),
            subtitle: Text(
              '${row['VEHICLE'] ?? ''} • ${row['REGION'] ?? ''} • ${row['TAHUN'] ?? ''}\n'
              '${row['OBJECT_DESCRIPTION'] ?? ''}\n'
              'Cabang: ${row['NAMA_CABANG'] ?? ''} (${row['KODE_CABANG'] ?? ''}) • Rev: ${row['REVISION'] ?? ''}',
              maxLines: 3,
            ),
            isThreeLine: true,
            trailing: Text(harga, style: const TextStyle(fontWeight: FontWeight.bold)),
            onTap: () => _showDetail(row),
          );
        },
      ),
    );
  }

  void _showDetail(Map<String, Object?> row) {
    String fmtHarga(dynamic v) => _rupiah.format((num.tryParse(v.toString()) ?? 0).round());
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('${row['BRAND'] ?? ''} • ${row['MODEL'] ?? ''}'),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _kv('Vehicle', row['VEHICLE']),
              _kv('Region', row['REGION']),
              _kv('Cabang', '${row['NAMA_CABANG'] ?? ''} (${row['KODE_CABANG'] ?? ''})'),
              _kv('Tahun', row['TAHUN']),
              _kv('Harga Pasar', fmtHarga(row['HARGA_PASAR'])),
              _kv('Object Type', row['OBJECT_TYPE']),
              _kv('Group Type Unit', row['GROUP_TYPE_UNIT']),
              const SizedBox(height: 8),
              Text('${row['OBJECT_DESCRIPTION'] ?? ''}'),
              const SizedBox(height: 6),
              _kv('Revision', row['REVISION']),
            ],
          ),
        ),
        actions: [ TextButton(onPressed: () => Navigator.pop(context), child: const Text('Tutup')) ],
      ),
    );
  }

  Widget _kv(String k, Object? v) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4.0),
      child: Row(children: [Text('$k: ', style: const TextStyle(fontWeight: FontWeight.bold)), Expanded(child: Text('${v ?? ''}'))]),
    );
  }

  Widget _buildTable() {
    if (_rows.isEmpty) return const Center(child: Text('Tidak ada data.'));
    final headers = const ['BRAND','MODEL','VEHICLE','REGION','CABANG','TAHUN','HARGA','REV','TYPE','GROUP'];
    return NotificationListener<ScrollNotification>(
      onNotification: (notif) {
        if (notif.metrics.pixels >= notif.metrics.maxScrollExtent - 100) {
          _loadMore();
        }
        return false;
      },
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          columns: headers.map((h) => DataColumn(label: Text(h))).toList(),
          rows: _rows.map((r) {
            String harga = _rupiah.format((num.tryParse((r['HARGA_PASAR'] ?? '0').toString()) ?? 0).round());
            return DataRow(cells: [
              DataCell(Text('${r['BRAND'] ?? ''}')),
              DataCell(Text('${r['MODEL'] ?? ''}')),
              DataCell(Text('${r['VEHICLE'] ?? ''}')),
              DataCell(Text('${r['REGION'] ?? ''}')),
              DataCell(Text('${r['NAMA_CABANG'] ?? ''}')),
              DataCell(Text('${r['TAHUN'] ?? ''}')),
              DataCell(Text(harga)),
              DataCell(Text('${r['REVISION'] ?? ''}')),
              DataCell(Text('${r['OBJECT_TYPE'] ?? ''}')),
              DataCell(Text('${r['GROUP_TYPE_UNIT'] ?? ''}')),
            ]);
          }).toList(),
        ),
      ),
    );
  }
}
