// Main file is large; kept in previous message content for reference.
// In this packaged ZIP, please replace with the provided code snippet in chat if needed.
