import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  final dark = prefs.getBool('dark') ?? false;
  final textScale = prefs.getDouble('textScale') ?? 1.0;
  final compact = prefs.getBool('compact') ?? false;
  runApp(OtrApp(initialDark: dark, initialTextScale: textScale, initialCompact: compact));
}
