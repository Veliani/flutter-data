import 'package:flutter/material.dart';

class SearchRow extends StatelessWidget {
  const SearchRow({
    super.key,
    required this.controller,
    required this.focusNode,
    required this.onChanged,
    required this.showFilters,
    required this.onToggleFilters,
    required this.onSavePreset,
  });

  final TextEditingController controller;
  final FocusNode focusNode;
  final ValueChanged<String> onChanged;
  final bool showFilters;
  final VoidCallback onToggleFilters;
  final VoidCallback onSavePreset;

  @override
  Widget build(BuildContext context) {
    final border = OutlineInputBorder(borderRadius: BorderRadius.circular(12));
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 6),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              focusNode: focusNode,
              controller: controller,
              decoration: InputDecoration(
                labelText: 'Kata kunci (brand/model/vehicle/desc/region)',
                border: border,
                prefixIcon: const Icon(Icons.search),
              ),
              onChanged: onChanged,
            ),
          ),
          const SizedBox(width: 8),
          IconButton(
            tooltip: showFilters ? 'Sembunyikan filter' : 'Tampilkan filter',
            onPressed: onToggleFilters,
            icon: const Icon(Icons.tune),
          ),
          const SizedBox(width: 4),
          FilledButton(onPressed: onSavePreset, child: const Text('Simpan')),
        ],
      ),
    );
  }
}
