import 'package:flutter/material.dart';
import '../models/saved_search.dart';

class PresetsChips extends StatelessWidget {
  const PresetsChips({super.key, required this.items, required this.onApply, required this.onDelete});

  final List<SavedSearch> items;
  final ValueChanged<SavedSearch> onApply;
  final ValueChanged<SavedSearch> onDelete;

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) return const SizedBox.shrink();
    return SizedBox(
      height: 44,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        scrollDirection: Axis.horizontal,
        itemCount: items.length,
        itemBuilder: (_, i) {
          final p = items[i];
          return InputChip(
            label: Text(p.label, overflow: TextOverflow.ellipsis),
            onPressed: () => onApply(p),
            onDeleted: () => onDelete(p),
            deleteIcon: const Icon(Icons.close),
          );
        },
        separatorBuilder: (_, __) => const SizedBox(width: 8),
      ),
    );
  }
}
