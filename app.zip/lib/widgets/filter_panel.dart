import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class FilterPanel extends StatelessWidget {
  const FilterPanel({
    super.key,
    required this.brands,
    required this.regions,
    required this.tahuns,
    required this.brand,
    required this.region,
    required this.tahunMin,
    required this.tahunMax,
    required this.onBrand,
    required this.onRegion,
    required this.onTahunMin,
    required this.onTahunMax,
    required this.hargaRange,
    required this.onHargaChange,
    required this.onHargaChangeEnd,
    required this.rupiah,
  });

  final List<String> brands;
  final List<String> regions;
  final List<String> tahuns;
  final String? brand;
  final String? region;
  final String? tahunMin;
  final String? tahunMax;
  final void Function(String?) onBrand;
  final void Function(String?) onRegion;
  final void Function(String?) onTahunMin;
  final void Function(String?) onTahunMax;
  final RangeValues hargaRange;
  final ValueChanged<RangeValues> onHargaChange;
  final ValueChanged<RangeValues> onHargaChangeEnd;
  final NumberFormat rupiah;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, c) {
        final twoCols = c.maxWidth > 520;
        final gap = const SizedBox(width: 8, height: 8);
        Widget row(List<Widget> children) => twoCols
            ? Row(children: [Expanded(child: children[0]), const SizedBox(width: 8), Expanded(child: children[1])])
            : Column(children: [children[0], gap, children[1]]);

        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          child: Column(
            children: [
              row([ _dd('Brand', brands, brand, onBrand),
                    _dd('Region', regions, region, onRegion), ]),
              const SizedBox(height: 8),
              row([ _dd('Tahun min', tahuns, tahunMin, onTahunMin),
                    _dd('Tahun max', tahuns, tahunMax, onTahunMax), ]),
              const SizedBox(height: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Text('Rentang harga (Rp.)', style: TextStyle(fontWeight: FontWeight.w600)),
                      const SizedBox(width: 8),
                      Text('${rupiah.format(hargaRange.start)} - ${rupiah.format(hargaRange.end)}', style: const TextStyle(fontSize: 12)),
                    ],
                  ),
                  RangeSlider(
                    values: hargaRange,
                    min: 0,
                    max: 200000000,
                    divisions: 200,
                    onChanged: onHargaChange,
                    onChangeEnd: onHargaChangeEnd,
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _dd(String label, List<String> options, String? value, void Function(String?) onChanged) {
    return DropdownButtonFormField<String>(
      isExpanded: true,
      decoration: InputDecoration(labelText: label, contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8)),
      items: [const DropdownMenuItem(value: '', child: Text('-')),
        ...options.map((e) => DropdownMenuItem(value: e, child: Text(e)))],
      value: (value ?? '').isEmpty ? '' : value,
      onChanged: (v) => onChanged((v ?? '').isEmpty ? null : v),
    );
  }
}
