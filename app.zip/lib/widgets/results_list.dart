import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class ResultsList extends StatelessWidget {
  final List<Map<String, Object?>> rows;
  final bool compact;
  final NumberFormat rupiah;
  final Function(Map<String, Object?>) onTap;

  const ResultsList({
    super.key,
    required this.rows,
    required this.compact,
    required this.rupiah,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: rows.length,
      itemBuilder: (context, index) {
        final r = rows[index];
        final model = (r['MODEL'] ?? '').toString();
        final vehicle = (r['VEHICLE'] ?? '').toString();
        final region = (r['REGION'] ?? '').toString();
        final tahun = (r['TAHUN'] ?? '').toString();
        final harga = rupiah.format(
          (num.tryParse((r['HARGA_PASAR'] ?? '0').toString()) ?? 0).round(),
        );
        final rev = rupiah.format(
          (num.tryParse((r['REVISION'] ?? '0').toString()) ?? 0).round(),
        );
        final desc = (r['OBJECT_DESCRIPTION'] ?? '').toString().trim();

        final lineTop = '$vehicle • $region • $tahun';
        final revText = 'Rev: $rev';

        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          child: ListTile(
            onTap: () => onTap(r),
            title: Text(
              model,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            subtitle: compact
                ? Text(lineTop, maxLines: 1)
                : Text(
                    desc.isNotEmpty ? '$lineTop\n$desc' : lineTop,
                    maxLines: 2,
                  ),
            trailing: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(harga, style: const TextStyle(fontWeight: FontWeight.bold)),
                Text(revText),
              ],
            ),
          ),
        );
      },
    );
  }
}
