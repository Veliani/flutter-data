
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class ResultsList extends StatelessWidget {
  final List<Map<String, Object?>> rows;
  final int density; // 0: normal, 1: compact, 2: ultra
  final NumberFormat rupiah;
  final Function(Map<String, Object?>) onTap;

  const ResultsList({
    super.key,
    required this.rows,
    required this.density,
    required this.rupiah,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final padV = density == 2 ? 4.0 : (density == 1 ? 6.0 : 8.0);
    final titleStyle = TextStyle(fontWeight: FontWeight.bold, fontSize: density == 2 ? 14 : (density == 1 ? 15 : 16));
    final subMax = density == 2 ? 1 : 2;

    return ListView.builder(
      itemCount: rows.length,
      itemBuilder: (context, index) {
        final r = rows[index];
        final model = (r['MODEL'] ?? '').toString();
        final vehicle = (r['VEHICLE'] ?? '').toString();
        final region = (r['REGION'] ?? '').toString();
        final tahun = (r['TAHUN'] ?? '').toString();
        final harga = rupiah.format((num.tryParse((r['HARGA_PASAR'] ?? '0').toString()) ?? 0).round());
        final rev = rupiah.format((num.tryParse((r['REVISION'] ?? '0').toString()) ?? 0).round());
        final desc = (r['OBJECT_DESCRIPTION'] ?? '').toString().trim();

        final lineTop = '$vehicle • $region • $tahun';
        final revText = 'Rev: $rev';

        return Card(
          margin: EdgeInsets.symmetric(horizontal: 8, vertical: padV/2),
          child: ListTile(
            dense: density > 0,
            contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: padV),
            onTap: () => onTap(r),
            title: Text(model, style: titleStyle),
            subtitle: Text(
              desc.isNotEmpty ? '$lineTop\n$desc' : lineTop,
              maxLines: subMax,
            ),
            trailing: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(harga, style: const TextStyle(fontWeight: FontWeight.bold)),
                if (density < 2) Text(revText),
              ],
            ),
          ),
        );
      },
    );
  }
}
