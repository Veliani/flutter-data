import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class ResultsList extends StatelessWidget {
  const ResultsList({
    super.key,
    required this.rows,
    required this.compact,
    required this.rupiah,
    required this.onTap,
  });

  final List<Map<String, Object?>> rows;
  final bool compact;
  final NumberFormat rupiah;
  final void Function(Map<String, Object?> row) onTap;

  @override
  Widget build(BuildContext context) {
    if (rows.isEmpty) return const Center(child: Text(''));
    return ListView.separated(
      itemCount: rows.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (context, i) {
        final r = rows[i];
        String h(dynamic v) => rupiah.format((num.tryParse(v.toString()) ?? 0).round());
        final desc = _sanitizeDesc(r['OBJECT_DESCRIPTION']);
        final title = Text('${r['MODEL'] ?? ''}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700));
        final lineTop = '${r['VEHICLE'] ?? ''} • ${r['REGION'] ?? ''} • ${r['TAHUN'] ?? ''}';
        final trailing = Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(h(r['HARGA_PASAR']), style: const TextStyle(fontWeight: FontWeight.bold)),
            Text('Rev: ${h(r['REVISION'] ?? 0)}', style: const TextStyle(fontSize: 12)),
          ],
        );
        return ListTile(
          dense: compact,
          minVerticalPadding: compact ? 4 : null,
          leading: compact ? null : CircleAvatar(child: Text(((r['BRAND'] ?? '') as String).isNotEmpty ? (r['BRAND'] as String)[0] : '?')),
          title: title,
          subtitle: compact ? Text(lineTop, maxLines: 1) : Text('$lineTop${desc.isNotEmpty ? '
$desc' : ''}', maxLines: 2),
          trailing: trailing,
          onTap: () => onTap(r),
        );
      },
    );
  }

  String _sanitizeDesc(dynamic v) {
    final s = (v ?? '').toString().trim();
    final reg = RegExp(r'^\d{4}([^\S\r\n]*(-|/)[^\S\r\n]*\d{4})?$');
    if (s.isEmpty) return '';
    if (reg.hasMatch(s)) return '';
    return s;
  }
}
