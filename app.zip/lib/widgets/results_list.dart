import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class ResultsList extends StatelessWidget {
  const ResultsList({
    super.key,
    required this.rows,
    required this.compact,
    required this.rupiah,
    required this.onTap,
  });

  final List<Map<String, Object?>> rows;
  final bool compact;
  final NumberFormat rupiah;
  final void Function(Map<String, Object?> row) onTap;

  TextStyle get _titleStyleCompact => const TextStyle(
        fontWeight: FontWeight.w600,
        fontSize: 13,
      );

  TextStyle get _subtitleStyleCompact => const TextStyle(
        fontSize: 12,
        height: 1.1,
      );

  TextStyle get _priceStyleCompact => const TextStyle(
        fontWeight: FontWeight.w700,
        fontSize: 13,
      );

  EdgeInsets get _cardMarginCompact =>
      const EdgeInsets.symmetric(horizontal: 6, vertical: 2);
  EdgeInsets get _tilePaddingCompact =>
      const EdgeInsets.symmetric(horizontal: 8, vertical: 4);

  @override
  Widget build(BuildContext context) {
    if (rows.isEmpty) return const Center(child: Text(''));
    return ListView.separated(
      itemCount: rows.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (context, i) {
        final r = rows[i];
        String h(dynamic v) => rupiah.format((num.tryParse(v.toString()) ?? 0).round());
        final desc = _sanitizeDesc(r['OBJECT_DESCRIPTION']);
        final title = Text('${r['MODEL'] ?? ''}', maxLines: 1, overflow: TextOverflow.ellipsis, style: compact ? _titleStyleCompact : const TextStyle(fontWeight: FontWeight.w700));
        final lineTop = '${r['VEHICLE'] ?? ''} • ${r['REGION'] ?? ''} • ${r['TAHUN'] ?? ''}';
        final trailing = Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(h(r['HARGA_PASAR']), style: compact ? _priceStyleCompact : const TextStyle(fontWeight: FontWeight.bold)),
            Text('Rev: ${h(r['REVISION'] ?? 0)}', style: compact ? const TextStyle(fontSize: 12) : const TextStyle(fontSize: 12)),
          ],
        );
        return Card(
          margin: compact ? _cardMarginCompact : const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          child: ListTile(
            dense: compact,
            visualDensity: compact ? const VisualDensity(horizontal: -2, vertical: -2) : VisualDensity.standard,
            contentPadding: compact ? _tilePaddingCompact : null,
            title: title,
            subtitle: compact
              ? Text(lineTop, maxLines: 1, style: _subtitleStyleCompact)
              : Text(desc.isNotEmpty ? '$lineTop\n$desc' : lineTop, maxLines: 2),
            trailing: trailing,
            onTap: () => onTap(r),
          ),
        );
      },
    );
  }

  String _sanitizeDesc(dynamic v) {
    final s = (v ?? '').toString().trim();
    final reg = RegExp(r'^\d{4}([^\S\r\n]*(-|/)[^\S\r\n]*\d{4})?$');
    if (s.isEmpty) return '';
    if (reg.hasMatch(s)) return '';
    return s;
  }
}
