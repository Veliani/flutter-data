import 'package:flutter/material.dart';

class SummaryBar extends StatelessWidget {
  const SummaryBar({super.key, required this.displayed, required this.total, required this.onReset, this.loading = false});
  final int displayed;
  final int total;
  final VoidCallback onReset;
  final bool loading;

  @override
  Widget build(BuildContext context) {
    if (displayed == 0 && !loading) {
      return const Padding(
        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        child: Align(alignment: Alignment.centerLeft, child: Text('Tidak ada hasil. Ubah filter/kata kunci.')),
      );
    }
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 4),
      child: Row(
        children: [
          Text('Hasil: ${displayed > total ? total : displayed} dari $total', style: const TextStyle(fontWeight: FontWeight.w600)),
          const Spacer(),
          TextButton(onPressed: onReset, child: const Text('Reset')),
        ],
      ),
    );
  }
}
