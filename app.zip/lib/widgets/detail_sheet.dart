import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

void showDetailSheet(BuildContext context, Map<String, Object?> r, NumberFormat rupiah) {
  String h(dynamic v) => rupiah.format((num.tryParse(v.toString()) ?? 0).round());
  showModalBottomSheet(
    context: context,
    useSafeArea: true,
    isScrollControlled: true,
    showDragHandle: true,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
    builder: (_) => Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(child: Text(((r['BRAND'] ?? '') as String).isNotEmpty ? (r['BRAND'] as String)[0] : '?')),
              const SizedBox(width: 12),
              Expanded(child: Text('${r['BRAND'] ?? ''} • ${r['MODEL'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16))),
              Text(h(r['HARGA_PASAR']), style: const TextStyle(fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 12),
          Wrap(spacing: 12, runSpacing: 8, children: [
            _chip(context, 'Vehicle', '${r['VEHICLE'] ?? ''}'),
            _chip(context, 'Region', '${r['REGION'] ?? ''}'),
            _chip(context, 'Tahun', '${r['TAHUN'] ?? ''}'),
            _chip(context, 'Revision', h(r['REVISION'] ?? 0)),
            _chip(context, 'Cabang', '${r['NAMA_CABANG'] ?? ''} (${r['KODE_CABANG'] ?? ''})'),
            _chip(context, 'Type', '${r['OBJECT_TYPE'] ?? ''}'),
            _chip(context, 'Group', '${r['GROUP_TYPE_UNIT'] ?? ''}'),
          ]),
          const SizedBox(height: 12),
          if (_sanitizeDesc(r['OBJECT_DESCRIPTION']).isNotEmpty)
            Text(_sanitizeDesc(r['OBJECT_DESCRIPTION']), style: const TextStyle(height: 1.3)),
        ],
      ),
    ),
  );
}

Widget _chip(BuildContext context, String label, String value) {
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(20),
      color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.6),
    ),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Text('$label: ', style: const TextStyle(fontWeight: FontWeight.w600)),
      Text(value),
    ]),
  );
}

String _sanitizeDesc(dynamic v) {
  final s = (v ?? '').toString().trim();
  final reg = RegExp(r'^\d{4}([^\S\r\n]*(-|/)[^\S\r\n]*\d{4})?$');
  if (s.isEmpty) return '';
  if (reg.hasMatch(s)) return '';
  return s;
}
