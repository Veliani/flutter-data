import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'pages/changelog_page.dart';
void showDetailSheet(BuildContext context, Map<String, Object?> r, NumberFormat rupiah) {
  String h(dynamic v) => rupiah.format((num.tryParse(v.toString()) ?? 0).round());
  showModalBottomSheet(
  context: context,
  isScrollControlled: true,
  useSafeArea: true,
  showDragHandle: true,
  builder: (_) => StatefulBuilder(
    builder: (context, set) {
      final h = MediaQuery.of(context).size.height * 0.6;
      return SizedBox(
        height: h,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 6, 12, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.settings, size: 20),
                  const SizedBox(width: 6),
                  const Text('Pengaturan', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                  const Spacer(),
                  IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close, size: 20)),
                ],
              ),
              const SizedBox(height: 4),
              const Divider(height: 8),
              Expanded(
                child: ListView(
                  children: [
                    SwitchListTile(
                      dense: true,
                      visualDensity: const VisualDensity(horizontal: -2, vertical: -2),
                      title: const Text('Dark mode'),
                      value: _dark,
                      onChanged: (v) => set(() { setState(() => _dark = v); _save(); }),
                      secondary: const Icon(Icons.dark_mode, size: 20),
                      contentPadding: EdgeInsets.zero,
                    ),
                    const SizedBox(height: 6),
                    const Text('Ukuran teks', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                    Row(
                      children: [
                        const Text('Kecil', style: TextStyle(fontSize: 12)),
                        Expanded(
                          child: Slider(
                            min: 0.9, max: 1.3, divisions: 8,
                            value: _textScale,
                            onChanged: (v) => set(() { setState(() => _textScale = v); _save(); }),
                          ),
                        ),
                        const Text('Besar', style: TextStyle(fontSize: 12)),
                      ],
                    ),
                    SwitchListTile(
                      dense: true,
                      visualDensity: const VisualDensity(horizontal: -2, vertical: -2),
                      title: const Text('Compact mode (daftar ringkas)'),
                      value: _compact,
                      onChanged: (v) => set(() { setState(() => _compact = v); _save(); }),
                      secondary: const Icon(Icons.view_agenda_outlined, size: 20),
                      contentPadding: EdgeInsets.zero,
                    ),
                    const Divider(height: 16),
                    const Text('Menu', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                    ListTile(
                      dense: true,
                      visualDensity: const VisualDensity(horizontal: -2, vertical: -2),
                      leading: const Icon(Icons.article_outlined, size: 20),
                      title: const Text('Changelog'),
                      trailing: const Icon(Icons.chevron_right, size: 18),
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ChangelogPage()));
                      },
                      contentPadding: EdgeInsets.zero,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    },
  ),
);
}

Widget _chip(BuildContext context, String label, String value) {
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(20),
      color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.6),
    ),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Text('$label: ', style: const TextStyle(fontWeight: FontWeight.w600)),
      Text(value),
    ]),
  );
}

String _sanitizeDesc(dynamic v) {
  final s = (v ?? '').toString().trim();
  final reg = RegExp(r'^\d{4}([^\S\r\n]*(-|/)[^\S\r\n]*\d{4})?$');
  if (s.isEmpty) return '';
  if (reg.hasMatch(s)) return '';
  return s;
}
