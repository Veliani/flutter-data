class AppConfig {
  // === Ganti sesuai GitHub-mu ===
  static const String githubRepoUser = 'Veliani';
  static const String githubRepoName = 'otr-db';
  static const String githubFilePath = 'harga_pasar_motor.db'; // di root repo
  static const String githubBranch = 'main';
  // Penting: isi tokenmu secara lokal sebelum build (JANGAN commit)
  static const String githubToken = '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';
}
