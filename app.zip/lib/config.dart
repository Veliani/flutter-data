
class AppConfig {
  static const String githubRepoUser = 'Veliani';
  static const String githubRepoName = 'otr-db';
  static const String githubFilePath = 'harga_pasar_motor.db';
  static const String githubBranch = 'main';
  static const String githubToken = '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';
}
