class SavedSearch {
  final String keyword;
  final String? brand;
  final String? region;
  final String? tahunMin;
  final String? tahunMax;
  final double hargaMin;
  final double hargaMax;
  const SavedSearch(this.keyword, this.brand, this.region, this.tahunMin, this.tahunMax, this.hargaMin, this.hargaMax);

  Map<String, dynamic> toJson() => {
    'keyword': keyword, 'brand': brand, 'region': region, 'tahunMin': tahunMin, 'tahunMax': tahunMax,
    'hargaMin': hargaMin, 'hargaMax': hargaMax,
  };
  static SavedSearch fromJson(Map<String, dynamic> j) => SavedSearch(
    j['keyword'] ?? '', j['brand'], j['region'], j['tahunMin'], j['tahunMax'],
    (j['hargaMin'] ?? 0).toDouble(), (j['hargaMax'] ?? 200000000).toDouble(),
  );
  String get label {
    final parts = <String>[];
    if (keyword.trim().isNotEmpty) parts.add(keyword.trim());
    if (brand != null && brand!.isNotEmpty) parts.add(brand!);
    if (region != null && region!.isNotEmpty) parts.add(region!);
    if (tahunMin != null && tahunMin!.isNotEmpty) parts.add('≥$tahunMin');
    if (tahunMax != null && tahunMax!.isNotEmpty) parts.add('≤$tahunMax');
    return parts.isEmpty ? 'Preset' : parts.join(' • ');
  }
}
