import 'package:flutter/material.dart';

class ChangelogPage extends StatelessWidget {
  const ChangelogPage({super.key});

  @override
  Widget build(BuildContext context) {
    final items = <_LogItem>[
      _LogItem('v7.1 (modular)', [
        'Pisah file UI: results_list, filter_panel, search_row, detail_sheet, dll.',
        'Performa & maintainability lebih baik.',
      ]),
      _LogItem('v7 (stable)', [
        'Tampilan table/list rapi, format Rp. untuk harga & revision.',
        'Cabang disembunyikan di list (muncul di detail).',
        'Sorting header, persist tema & ukuran teks, realtime search.',
        'Compact/expanded mode, summary bar, toggle table via long-press judul.',
      ]),
      _LogItem('v6', [
        'Perbaikan Gradle/AGP hingga build sukses.',
        "Rapihin layout kartu (vehicle • region • tahun).",
      ]),
      _LogItem('Beta V1–V5', [
        'Bootstrap Flutter + DB pre-bundled .db.',
        'Pencarian awal, filter dasar, dan format tampilan awal.',
      ]),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Changelog')),
      body: ListView.separated(
        itemCount: items.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (context, i) {
          final it = items[i];
          return ListTile(
            title: Text(it.version, style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: it.points.map((p) => Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text('• ' + p),
              )).toList(),
            ),
          );
        },
      ),
    );
  }
}

class _LogItem {
  final String version;
  final List<String> points;
  const _LogItem(this.version, this.points);
}
