
import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';

class AboutPage extends StatefulWidget {
  const AboutPage({super.key});
  @override
  State<AboutPage> createState() => _AboutPageState();
}

class _AboutPageState extends State<AboutPage> {
  String _version = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final info = await PackageInfo.fromPlatform();
      setState(() => _version = '${info.version}+${info.buildNumber}');
    } catch (_) {
      setState(() => _version = 'unknown');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tentang Aplikasi')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const ListTile(
            contentPadding: EdgeInsets.zero,
            title: Text('Pencarian Data OTR', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            subtitle: Text('Aplikasi pencarian data OTR dengan database lokal SQLite.'),
          ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.tag),
            title: const Text('Versi'),
            subtitle: Text(_version.isEmpty ? '-' : _version),
          ),
          const SizedBox(height: 16),
          const Text('Lisensi Paket', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          ElevatedButton.icon(
            icon: const Icon(Icons.description_outlined),
            label: const Text('Lihat Lisensi Open Source'),
            onPressed: () => showLicensePage(
              context: context,
              applicationName: 'Pencarian Data OTR',
            ),
          ),
          const SizedBox(height: 24),
          const Text('Catatan'),
          const Text('Semua data disimpan offline di perangkat Anda.'),
        ],
      ),
    );
  }
}
