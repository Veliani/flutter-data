
import 'package:flutter/material.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({
    super.key,
    required this.dark,
    required this.onDarkChanged,
    required this.textScale,
    required this.onTextScaleChanged,
    required this.compact,
    required this.onCompactChanged,
    required this.ultraCompact,
    required this.onUltraCompactChanged,
    this.appVersion,
    this.onOpenAbout,
  });

  final bool dark;
  final ValueChanged<bool> onDarkChanged;

  final double textScale;
  final ValueChanged<double> onTextScaleChanged;

  final bool compact;
  final ValueChanged<bool> onCompactChanged;

  final bool ultraCompact;
  final ValueChanged<bool> onUltraCompactChanged;

  final String? appVersion;
  final VoidCallback? onOpenAbout;

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late bool _dark = widget.dark;
  late double _scale = widget.textScale;
  late bool _compact = widget.compact;
  late bool _ultra = widget.ultraCompact;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Pengaturan')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        children: [
          SwitchListTile(
            title: const Text('Dark mode'),
            value: _dark,
            onChanged: (v) { setState(() => _dark = v); widget.onDarkChanged(v); },
            secondary: const Icon(Icons.dark_mode),
            contentPadding: EdgeInsets.zero,
          ),
          const SizedBox(height: 8),
          const Text('Ukuran teks', style: TextStyle(fontWeight: FontWeight.w600)),
          Row(
            children: [
              const Text('Kecil'),
              Expanded(
                child: Slider(
                  min: 0.9, max: 1.3, divisions: 8,
                  value: _scale,
                  onChanged: (v) { setState(() => _scale = v); widget.onTextScaleChanged(v); },
                ),
              ),
              const Text('Besar'),
            ],
          ),
          SwitchListTile(
            title: const Text('Compact mode'),
            value: _compact,
            onChanged: (v) { setState(() => _compact = v); widget.onCompactChanged(v); },
            secondary: const Icon(Icons.view_agenda_outlined),
            contentPadding: EdgeInsets.zero,
          ),
          SwitchListTile(
            title: const Text('Compact++ (ekstra rapat)'),
            value: _ultra,
            onChanged: (v) { setState(() => _ultra = v); widget.onUltraCompactChanged(v); },
            secondary: const Icon(Icons.dehaze),
            contentPadding: EdgeInsets.zero,
          ),
          const Divider(height: 24),
          if (widget.appVersion != null)
            ListTile(
              dense: true,
              leading: const Icon(Icons.info_outline),
              title: Text('Versi: ${widget.appVersion}'),
            ),
          ListTile(
            leading: const Icon(Icons.description_outlined),
            title: const Text('Tentang & Lisensi'),
            trailing: const Icon(Icons.chevron_right),
            onTap: widget.onOpenAbout,
          ),
        ],
      ),
    );
  }
}
