
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:intl/intl.dart';

import '../services/db_service.dart';
import '../widgets/search_row.dart';
import '../widgets/summary_bar.dart';
import '../widgets/results_list.dart';
import '../widgets/detail_sheet.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.onOpenSettings, required this.compact, required this.ultraCompact});
  final void Function(BuildContext context) onOpenSettings;
  final bool compact;
  final bool ultraCompact;

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Database? _db;
  bool _loading = true;
  bool _tableView = false;

  final _searchCtrl = TextEditingController();
  final _searchFocus = FocusNode();
  Timer? _debounce;
  String _keyword = '';

  final String _table = 'Sheet1';
  final List<String> _selectColumns = const [
    'BRAND','VEHICLE','MODEL','REGION','TAHUN','HARGA_PASAR',
    'OBJECT_DESCRIPTION','NAMA_CABANG','KODE_CABANG','REVISION','OBJECT_TYPE','GROUP_TYPE_UNIT'
  ];

  List<Map<String, Object?>> _rows = [];
  int _limit = 50, _offset = 0; bool _hasMore = true;

  int? _sortColumnIndex; bool _sortAsc = true;
  String _orderBy = 'BRAND ASC, MODEL ASC, TAHUN ASC';

  int _totalCount = 0;

  int get _density => widget.ultraCompact ? 2 : (widget.compact ? 1 : 0);
  final _rupiah = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp.', decimalDigits: 0);

  @override
  void initState() {
    super.initState();
    Intl.defaultLocale = 'id_ID';
    _initDb();
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _searchCtrl.dispose();
    _searchFocus.dispose();
    super.dispose();
  }

  Future<void> _initDb() async {
    final db = await DbService.openPreloadedDb();
    setState(() { _db = db; _loading = false; });
    await _refresh();
  }

  Future<void> _refresh() async {
    if (_db == null) return;
    setState(() { _loading = true; _rows = []; _offset = 0; _hasMore = true; });
    await _updateCounts();
    await _loadMore();
    setState(() { _loading = false; });
  }

  Future<void> _updateCounts() async {
    final args = <Object?>[]; final where = _buildWhereClause(args);
    final res = await _db!.rawQuery('SELECT COUNT(*) as c FROM $_table $where', args);
    _totalCount = int.tryParse((res.first['c']).toString()) ?? 0;
  }

  String _buildWhereClause(List<Object?> argsOut) {
    final parts = <String>[];
    if (_keyword.trim().isNotEmpty) {
      final like = '%${_keyword.trim()}%';
      parts.add('(BRAND LIKE ? OR VEHICLE LIKE ? OR MODEL LIKE ? OR OBJECT_DESCRIPTION LIKE ? OR REGION LIKE ?)');
      argsOut.addAll([like, like, like, like, like]);
    }
    return parts.isEmpty ? '' : 'WHERE ' + parts.join(' AND ');
  }

  Future<void> _loadMore() async {
    if (!_hasMore || _db == null) return;
    final args = <Object?>[]; final where = _buildWhereClause(args);
    final sql = 'SELECT ${_selectColumns.join(', ')} FROM $_table $where ORDER BY $_orderBy LIMIT $_limit OFFSET $_offset';
    final result = await _db!.rawQuery(sql, args);
    setState(() {
      _rows.addAll(result);
      _offset += result.length;
      _hasMore = result.length == _limit;
    });
  }

  void _reset() {
    setState(() {
      _keyword = ''; _searchCtrl.clear();
      _orderBy = 'BRAND ASC, MODEL ASC, TAHUN ASC';
      _sortColumnIndex = null; _sortAsc = true;
    });
    _refresh();
    _searchFocus.requestFocus();
  }

  void _onSearchChanged(String v) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 400), () {
      setState(() => _keyword = v);
      _refresh();
      _searchFocus.requestFocus();
    });
  }

  void _applySortKey(String key) {
    setState(() {
      final parts = key.split(' ');
      final col = parts[0];
      final desc = parts.length > 1 and parts[1] == 'DESC';
      _orderBy = f"{col} {'DESC' if desc else 'ASC'}, MODEL ASC, TAHUN ASC";
      _sortAsc = not desc;
      _sortColumnIndex = None;
    })
    _refresh();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: GestureDetector(
          onLongPress: () => setState(() => _tableView = !_tableView),
          child: const Text('Pencarian Data OTR'),
        ),
        actions: [
          PopupMenuButton<String>(
            tooltip: 'Urutkan',
            icon: const Icon(Icons.sort),
            onSelected: _applySortKey,
            itemBuilder: (ctx) => const [
              PopupMenuItem(value: 'HARGA_PASAR ASC', child: Text('Harga ↑')),
              PopupMenuItem(value: 'HARGA_PASAR DESC', child: Text('Harga ↓')),
              PopupMenuItem(value: 'TAHUN ASC', child: Text('Tahun ↑')),
              PopupMenuItem(value: 'TAHUN DESC', child: Text('Tahun ↓')),
              PopupMenuItem(value: 'REGION ASC', child: Text('Region A→Z')),
              PopupMenuItem(value: 'REGION DESC', child: Text('Region Z→A')),
              PopupMenuItem(value: 'BRAND ASC', child: Text('Brand A→Z')),
              PopupMenuItem(value: 'BRAND DESC', child: Text('Brand Z→A')),
            ],
          ),
          IconButton(
            tooltip: 'Pengaturan',
            onPressed: () => widget.onOpenSettings(context),
            icon: const Icon(Icons.settings),
          ),
        ],
      ),
      body: NotificationListener<ScrollNotification>(
        onNotification: (n) { if (n.metrics.pixels >= n.metrics.maxScrollExtent - 100) _loadMore(); return false; },
        child: Column(
          children: [
            SearchRow(
              controller: _searchCtrl,
              focusNode: _searchFocus,
              onChanged: _onSearchChanged,
            ),
            if (_loading) const LinearProgressIndicator(minHeight: 2),
            SummaryBar(displayed: _rows.length, total: _totalCount, onReset: _reset, loading: _loading),
            const Divider(height: 1),
            Expanded(child: _tableView ? _buildTable() : _buildResults()),
          ],
        ),
      ),
    );
  }

  Widget _buildResults() {
    if (_rows.isEmpty) return const Center(child: Text(''));
    return ResultsList(
      rows: _rows,
      density: _density,
      rupiah: _rupiah,
      onTap: (r) => showDetailSheet(context, r, _rupiah),
    );
  }

  Widget _buildTable() {
    if (_rows.isEmpty) return const Center(child: Text('Tidak ada data.'));
    final columns = <DataColumn>[
      DataColumn(label: const Text('MODEL'), onSort: (i, _) => _applySortKey('MODEL ASC')),
      DataColumn(label: const Text('VEHICLE'), onSort: (i, _) => _applySortKey('VEHICLE ASC')),
      DataColumn(label: const Text('REGION'), onSort: (i, _) => _applySortKey('REGION ASC')),
      DataColumn(label: const Text('TAHUN'), numeric: true, onSort: (i, _) => _applySortKey('TAHUN ASC')),
      DataColumn(label: const Text('HARGA (Rp.)'), numeric: true, onSort: (i, _) => _applySortKey('HARGA_PASAR ASC')),
      DataColumn(label: const Text('REV (Rp.)'), numeric: true, onSort: (i, _) => _applySortKey('REVISION ASC')),
      DataColumn(label: const Text('BRAND'), onSort: (i, _) => _applySortKey('BRAND ASC')),
      DataColumn(label: const Text('TYPE'), onSort: (i, _) => _applySortKey('OBJECT_TYPE ASC')),
      DataColumn(label: const Text('GROUP'), onSort: (i, _) => _applySortKey('GROUP_TYPE_UNIT ASC')),
    ];

    List<DataRow> rows = _rows.map((r) {
      String harga = _rupiah.format((num.tryParse((r['HARGA_PASAR'] ?? '0').toString()) ?? 0).round());
      String rev = _rupiah.format((num.tryParse((r['REVISION'] ?? '0').toString()) ?? 0).round());
      return DataRow(cells: [
        DataCell(SizedBox(width: 160, child: Text('${r['MODEL'] ?? ''}', overflow: TextOverflow.ellipsis))),
        DataCell(SizedBox(width: 140, child: Text('${r['VEHICLE'] ?? ''}', overflow: TextOverflow.ellipsis))),
        DataCell(SizedBox(width: 140, child: Text('${r['REGION'] ?? ''}', overflow: TextOverflow.ellipsis))),
        DataCell(Text('${r['TAHUN'] ?? ''}')),
        DataCell(Text(harga)),
        DataCell(Text(rev)),
        DataCell(SizedBox(width: 110, child: Text('${r['BRAND'] ?? ''}', overflow: TextOverflow.ellipsis))),
        DataCell(SizedBox(width: 120, child: Text('${r['OBJECT_TYPE'] ?? ''}', overflow: TextOverflow.ellipsis))),
        DataCell(SizedBox(width: 140, child: Text('${r['GROUP_TYPE_UNIT'] ?? ''}', overflow: TextOverflow.ellipsis))),
      ]);
    }).toList();

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: DataTable(
        sortColumnIndex: _sortColumnIndex,
        sortAscending: _sortAsc,
        columns: columns,
        rows: rows,
      ),
    );
  }
}
